#!/bin/sh
cd "$(dirname "$0")"
[ -d node_modules ] || npm install
mkdir -p out
npx remotion render src/index.jsx LondonBridge out/london_bridge.mp4 --codec=h264 --gl=angle --concurrency=4 --timeout=180000
