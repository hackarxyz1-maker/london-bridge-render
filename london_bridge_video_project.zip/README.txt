London Bridge goes to Arizona - 3D story video (Remotion + three.js)
Run:  render.bat (Windows)  or  ./render.sh   -> out/london_bridge.mp4  (62.4 s, 720x1280, 30 fps)
Needs Node 18+. First run installs packages. If render is slow/black frames, change --gl=angle to --gl=swangle (CPU, much slower).
Preview in browser: npm start
Audio: public/voiceover.wav = your voice-over + sound effects (rebuild: python3 audio/make_sfx.py, needs numpy+scipy).
Original voice only: public/voiceover_original.wav
Timing of every shot/word: src/timing.js. Cameras and moods: src/shots.js. Locations: src/worlds.jsx.
