@echo off
REM Renders the London Bridge video (720x1280, 30 fps, voice + sound effects included).
cd /d "%~dp0"
if not exist node_modules call npm install
if not exist out mkdir out
call npx remotion render src/index.jsx LondonBridge out\london_bridge.mp4 --codec=h264 --gl=angle --concurrency=4 --timeout=180000
echo.
echo Done: out\london_bridge.mp4
pause
