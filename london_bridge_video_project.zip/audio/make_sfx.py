"""Builds sound effects timed to the voice-over and mixes them with it.
Input : public/voiceover_original.wav   Output: public/voiceover.wav (voice + effects), audio/sfx_only.wav"""
import numpy as np, scipy.io.wavfile as wav
from scipy.signal import butter, sosfilt
SR = 44100; DUR = 62.4; N = int(SR * DUR)
rng = np.random.default_rng(7)
vo_sr, vo = wav.read('public/voiceover_original.wav'); vo = vo.astype(np.float64) / 32768
assert vo_sr == SR
vo = np.pad(vo, (0, max(0, N - len(vo))))[:N]

def bp(x, lo, hi, order=2):
    return sosfilt(butter(order, [lo, hi], btype='band', fs=SR, output='sos'), x)
def lp(x, f, order=2): return sosfilt(butter(order, f, btype='low', fs=SR, output='sos'), x)
def hp(x, f, order=2): return sosfilt(butter(order, f, btype='high', fs=SR, output='sos'), x)
def env(n, a=0.01, d=0.2, curve=3.0):
    t = np.arange(n) / SR; e = np.minimum(1, t / max(a, 1e-4)) * np.exp(-t * curve / max(d, 1e-3)); return e
def noise(n): return rng.standard_normal(n)
def put(buf, x, t0, gain=1.0):
    i = int(t0 * SR); 
    if i >= len(buf): return
    x = x[: len(buf) - i] if i >= 0 else x[-i:]
    i = max(i, 0); buf[i:i + len(x)] += x * gain

# ---------- sound builders ----------
def whoosh(dur=0.6, f0=300, f1=2500, peak=0.5):
    n = int(dur * SR); x = noise(n); t = np.linspace(0, 1, n)
    out = np.zeros(n); k = 12
    for j in range(k):  # sweeping band via blended bands
        a = j / (k - 1); f = f0 * (f1 / f0) ** a
        band = bp(x, f * 0.7, f * 1.4); w = np.exp(-((t - (0.15 + 0.7 * a)) ** 2) / 0.02); out += band * w
    out *= np.sin(np.pi * t) ** 1.5; return out / (np.abs(out).max() + 1e-9) * peak
def thump(f=70, dur=0.5, peak=0.8, click=0.3):
    n = int(dur * SR); t = np.arange(n) / SR
    x = np.sin(2 * np.pi * (f + 40 * np.exp(-t * 30)) * t) * np.exp(-t * 9) + click * lp(noise(n), 900) * np.exp(-t * 60)
    return x / np.abs(x).max() * peak
def tick(f=1800, dur=0.06, peak=0.4):
    n = int(dur * SR); x = bp(noise(n), f * 0.6, f * 1.6) * env(n, 0.0005, dur, 5); return x / (np.abs(x).max() + 1e-9) * peak
def knock(f=420, peak=0.6):
    n = int(0.18 * SR); t = np.arange(n) / SR
    x = np.sin(2 * np.pi * f * t) * np.exp(-t * 38) + 0.5 * np.sin(2 * np.pi * f * 2.3 * t) * np.exp(-t * 55) + 0.3 * bp(noise(n), 800, 3000) * np.exp(-t * 90)
    return x / np.abs(x).max() * peak
def bell(f=880, dur=1.2, peak=0.35):
    n = int(dur * SR); t = np.arange(n) / SR
    x = sum(a * np.sin(2 * np.pi * f * m * t) * np.exp(-t * (3 + 2.5 * m)) for m, a in [(1, 1), (2.01, 0.5), (3.02, 0.25), (4.2, 0.12)])
    x *= np.minimum(1, t / 0.003); return x / np.abs(x).max() * peak
def pop(peak=0.5):
    n = int(0.12 * SR); t = np.arange(n) / SR; x = np.sin(2 * np.pi * (500 + 900 * np.exp(-t * 40)) * t) * np.exp(-t * 35); return x / np.abs(x).max() * peak
def rise(dur=0.5, f0=400, f1=1600, peak=0.3):
    n = int(dur * SR); t = np.linspace(0, 1, n); ph = 2 * np.pi * np.cumsum(f0 * (f1 / f0) ** t) / SR
    x = np.sin(ph) * np.sin(np.pi * t) ** 2; return x * peak
def horn(f=110, dur=1.5, peak=0.55):
    n = int(dur * SR); t = np.arange(n) / SR
    x = sum(np.sign(np.sin(2 * np.pi * ff * t)) * a for ff, a in [(f, 1), (f * 1.5, 0.7), (f * 2.0, 0.3)])
    x = lp(x, 900) * np.minimum(1, t / 0.12) * np.minimum(1, (dur - t) / 0.4); return x / np.abs(x).max() * peak
def honk(f=420, dur=0.28, peak=0.3):
    n = int(dur * SR); t = np.arange(n) / SR
    x = lp(np.sign(np.sin(2 * np.pi * f * t)) + np.sign(np.sin(2 * np.pi * f * 1.26 * t)), 1500) * np.minimum(1, t / 0.01) * np.minimum(1, (dur - t) / 0.05); return x / np.abs(x).max() * peak
def scrape(dur=1.5, peak=0.35, lo=300, hi=2500):
    n = int(dur * SR); t = np.linspace(0, 1, n); x = bp(noise(n), lo, hi) * (0.6 + 0.4 * np.sin(2 * np.pi * 7 * t + 1)) * np.sin(np.pi * t) ** 0.7
    return x / (np.abs(x).max() + 1e-9) * peak
def groan(dur=1.5, f=55, peak=0.4):
    n = int(dur * SR); t = np.arange(n) / SR
    x = np.sin(2 * np.pi * (f + 14 * np.sin(2 * np.pi * 2.2 * t)) * t) + 0.5 * np.sin(2 * np.pi * (f * 2.01) * t) + 0.3 * lp(noise(n), 300)
    return x * np.sin(np.pi * t / dur) ** 1.2 / 1.8 * peak
def drip(peak=0.25):
    n = int(0.15 * SR); t = np.arange(n) / SR; x = np.sin(2 * np.pi * (1400 + 1800 * t * 8) * t) * np.exp(-t * 30); return x / np.abs(x).max() * peak
def chain(dur=0.9, peak=0.3):
    out = np.zeros(int(dur * SR))
    for k in range(18): put(out, tick(rng.uniform(2500, 5000), 0.05, 0.8), k * dur / 20 + rng.uniform(0, 0.015))
    return out / (np.abs(out).max() + 1e-9) * peak
def regchime(peak=0.4): # ka-ching
    out = np.zeros(int(1.6 * SR)); put(out, tick(3000, 0.05, 0.9), 0); put(out, thump(180, 0.12, 0.5), 0.02)
    put(out, bell(1568, 1.4, 0.9), 0.1); put(out, bell(2093, 1.3, 0.7), 0.16); return out / np.abs(out).max() * peak
def splash(peak=0.4):
    n = int(0.9 * SR); x = bp(noise(n), 400, 4000) * env(n, 0.01, 0.5, 4); return x / np.abs(x).max() * peak
def poof(peak=0.4):
    n = int(0.8 * SR); x = lp(noise(n), 1200) * env(n, 0.01, 0.35, 4); return x / np.abs(x).max() * peak
def flap(dur=0.8, peak=0.25):
    n = int(dur * SR); t = np.linspace(0, 1, n); x = bp(noise(n), 200, 1800) * (0.4 + 0.6 * np.abs(np.sin(2 * np.pi * 9 * t))) * np.sin(np.pi * t); return x / (np.abs(x).max() + 1e-9) * peak
def applause(dur, peak=0.3):
    n = int(dur * SR); out = np.zeros(n)
    for _ in range(int(dur * 170)):
        put(out, tick(rng.uniform(1500, 4500), rng.uniform(0.01, 0.03), rng.uniform(0.2, 1.0)), rng.uniform(0, dur - 0.05))
    out = lp(out, 6000) * np.sin(np.pi * np.linspace(0, 1, n)) ** 0.5; return out / (np.abs(out).max() + 1e-9) * peak
def fanfare(peak=0.22):
    out = np.zeros(int(1.4 * SR))
    for f, t0, d in [(392, 0, 0.28), (523, 0.3, 0.28), (659, 0.6, 0.7)]:
        n = int(d * SR); t = np.arange(n) / SR; x = lp(np.sign(np.sin(2 * np.pi * f * t)) + 0.5 * np.sin(2 * np.pi * 2 * f * t), 2500) * np.minimum(1, t / 0.03) * np.minimum(1, (d - t) / 0.1)
        put(out, x, t0)
    return out / np.abs(out).max() * peak
def car(dur=1.4, peak=0.3, up=True):
    n = int(dur * SR); t = np.linspace(0, 1, n); x = lp(noise(n), 700) * np.sin(np.pi * t) ** 1.5; hum = np.sin(2 * np.pi * np.cumsum(90 + 40 * (t if up else 1 - t)) / SR) * np.sin(np.pi * t) ** 2
    y = x + 0.5 * hum; return y / np.abs(y).max() * peak
def gull(peak=0.14):
    n = int(0.5 * SR); t = np.linspace(0, 1, n); f = 1700 + 900 * np.sin(np.pi * t) - 600 * t; x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.sin(np.pi * t) ** 1.2; return x * peak

# ---------- ambience beds ----------
def bed(kind, dur, peak):
    n = int(dur * SR); t = np.arange(n) / SR
    if kind == 'wind': x = lp(noise(n), 450) * (0.6 + 0.4 * np.sin(2 * np.pi * 0.23 * t + 1)) + 0.3 * bp(noise(n), 800, 1600) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.17 * t))
    elif kind == 'water': x = lp(noise(n), 600) * (0.55 + 0.45 * np.sin(2 * np.pi * 0.45 * t)) + 0.2 * bp(noise(n), 1200, 3000) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.6 * t + 2))
    elif kind == 'room': x = lp(noise(n), 220) + 0.15 * np.sin(2 * np.pi * 50 * t)
    elif kind == 'harbor': x = lp(noise(n), 700) * (0.55 + 0.45 * np.sin(2 * np.pi * 0.35 * t)) + 0.25 * bp(noise(n), 100, 250)
    elif kind == 'crowd': x = bp(noise(n), 300, 1800) * (0.6 + 0.4 * np.sin(2 * np.pi * 0.6 * t)) * 0.8
    elif kind == 'site': x = lp(noise(n), 500) * (0.6 + 0.4 * np.sin(2 * np.pi * 0.3 * t)) + 0.2 * bp(noise(n), 100, 300)
    x /= np.abs(x).max(); fade = np.minimum(1, np.minimum(t / 0.4, (dur - t) / 0.4)); return x * fade * peak

sfx = np.zeros(N)
beds = [('wind', 0, 6.2, 0.10), ('water', 6.2, 18.4, 0.11), ('room', 18.4, 32.45, 0.10), ('harbor', 32.45, 40.7, 0.12), ('site', 40.7, 46.05, 0.09), ('crowd', 46.05, 53.25, 0.09), ('wind', 53.25, 58.1, 0.10), ('wind', 58.1, 62.4, 0.12)]
for k, a, b, g in beds: put(sfx, bed(k, b - a + 0.5, g), a - 0.25)
put(sfx, bed('water', 62.4 - 53.25, 0.05), 53.25)

S = []  # (time, sound)
S += [(0.05, whoosh(1.2, 250, 1800, 0.35))]
for c in [6.2, 18.4, 23.7, 32.45, 40.7, 46.05, 53.25, 58.1]: S += [(c - 0.22, whoosh(0.5, 400, 3000, 0.45))]
S += [(7.5, bell(1320, 1.4, 0.3)), (10.15, honk(420, 0.3, 0.3)), (10.9, honk(380, 0.35, 0.28))]
for st in [8.8, 9.6, 10.4]: S += [(st, car(1.6, 0.18, True))]
S += [(12.35, groan(1.6, 52, 0.45)), (13.0, drip(0.28)), (13.9, drip(0.25)), (14.55, whoosh(0.35, 800, 4000, 0.4)), (14.9, tick(2600, 0.06, 0.4)),
      (16.0, pop(0.5)), (16.9, groan(1.5, 48, 0.5)), (17.9, thump(60, 0.5, 0.45))]
S += [(20.35, rise(0.3, 500, 1800, 0.3)), (20.62, bell(1760, 1.0, 0.32)), (22.45, pop(0.4)), (23.2, pop(0.5)), (23.25, knock(300, 0.5)), (23.52, knock(380, 0.7)), (23.62, knock(380, 0.55))]
S += [(24.3, scrape(0.35, 0.2, 2000, 6000)), (28.7, thump(95, 0.4, 0.7)), (28.75, scrape(0.25, 0.25, 3000, 7000)), (29.5, tick(1500, 0.07, 0.5)), (30.2, tick(1500, 0.07, 0.5)), (31.45, tick(1500, 0.07, 0.5)), (32.3, regchime(0.45))]
S += [(32.1, rise(0.5, 120, 400, 0.25)), (32.62, thump(52, 0.9, 0.85)), (33.9, scrape(1.0, 0.18, 200, 1200))]
for i, tt in enumerate(np.arange(35.9, 38.6, 0.34)): S += [(float(tt), scrape(0.18, 0.18, 1500, 6000)), (float(tt) + 0.17, tick(2200, 0.04, 0.2))]
S += [(36.0, tick(900, 0.12, 0.5)), (36.05, chain(0.9, 0.2)), (38.75, thump(80, 0.3, 0.5)), (38.95, horn(110, 1.5, 0.5)), (39.9, splash(0.28))]
S += [(40.6, whoosh(0.5, 300, 2500, 0.4)), (41.0, bell(1568, 0.8, 0.28)), (41.6, scrape(1.9, 0.4, 150, 2000)), (43.5, thump(70, 0.6, 0.6)), (43.3, groan(1.2, 60, 0.3)), (45.05, pop(0.5)), (45.2, thump(65, 0.7, 0.75))]
S += [(47.55, chain(0.9, 0.3)), (48.4, thump(55, 0.9, 0.9)), (48.42, poof(0.4)), (48.75, scrape(0.4, 0.25, 1500, 5000)), (49.25, scrape(0.4, 0.25, 1500, 5000)), (49.65, scrape(0.4, 0.25, 1500, 5000))]
S += [(50.3, flap(0.8, 0.28)), (50.5, applause(2.6, 0.32)), (50.6, fanfare(0.2))]
S += [(54.7, car(1.6, 0.28, True)), (55.9, car(1.6, 0.28, False)), (57.0, car(1.4, 0.25, True))]
S += [(59.3, bell(659, 1.5, 0.28)), (59.55, bell(784, 1.5, 0.25)), (59.8, bell(988, 1.8, 0.28)), (61.45, bell(523, 2.4, 0.3))]
for tt in [36.4, 36.9, 53.5]: S += [(tt, gull(0.12))]
for tt, s in S: put(sfx, s, tt)

# ---------- mix: duck effects under the voice, then limit ----------
win = int(0.08 * SR); e = np.sqrt(np.convolve(vo ** 2, np.ones(win) / win, mode='same')); e = e / (e.max() + 1e-9)
duck = 1 - 0.35 * np.clip(e * 2.5, 0, 1)
sfx_d = sfx * duck * 0.45
mix = vo * 0.88 + sfx_d * 1.0
peak = np.abs(mix).max(); mix = np.tanh(mix * (0.95 / max(peak, 0.95))) / np.tanh(1.0) * 0.97 if peak > 0.97 else mix
wav.write('public/voiceover.wav', SR, (np.clip(mix, -1, 1) * 32767).astype(np.int16))
wav.write('audio/sfx_only.wav', SR, (np.clip(sfx / max(np.abs(sfx).max(), 1) * 0.9, -1, 1) * 32767).astype(np.int16))
print('mix peak', float(np.abs(mix).max()), 'sfx rms', float(np.sqrt(np.mean(sfx ** 2))), 'vo rms', float(np.sqrt(np.mean(vo ** 2))), 'events', len(S))
