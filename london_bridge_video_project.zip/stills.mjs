import { bundle } from '@remotion/bundler';
import { renderStill, selectComposition } from '@remotion/renderer';
import fs from 'fs';
const frames = process.argv.slice(2).map(Number);
const chrome = '/opt/pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell';
const serveUrl = await bundle({ entryPoint: './src/index.jsx', onProgress: () => {} });
const opts = { browserExecutable: chrome, chromiumOptions: { gl: 'swangle' }, timeoutInMilliseconds: 240000 };
const comp = await selectComposition({ serveUrl, id: 'LondonBridge', ...opts });
fs.mkdirSync('stills', { recursive: true });
for (const f of frames) {
  const t0 = Date.now();
  await renderStill({ composition: comp, serveUrl, frame: f, output: `stills/f${String(f).padStart(4, '0')}.png`, scale: 0.5, ...opts });
  console.log('frame', f, ((Date.now() - t0) / 1000).toFixed(1) + 's');
}
process.exit(0);
