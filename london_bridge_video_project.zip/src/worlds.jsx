import React from 'react';
import * as THREE from 'three';
import { Box, Cyl, Sph, Part, M, C, Cd, G, memo, signTex, Label, Ground, clamp, ease, seg, labelCanvas, font, INK, CREAM, rngFrom, signMat } from './kit.jsx';
import { Person } from './chars.jsx';
import { DECK, groundY, bridgeGeo, Bridge, Banks, Water, Roads, Bus, Car, SignPost, Plaque, Cactus, Rock, Mountains, Sky, Puff, MapBoard, Ship, Crane } from './props.jsx';
import { W } from './timing.js';

const pop = (t, t0, d = 0.35) => { const x = clamp((t - t0) / d, 0, 1); return x <= 0 ? 0 : ease(x) + 0.2 * Math.sin(x * Math.PI) * (1 - x); };
const mod = (a, n) => ((a % n) + n) % n;

// ================= traffic on the deck =================
function Traffic({ t, list }) {
  return list.map((v, i) => {
    const x = mod(v.x0 + v.dir * v.v * t + 30, 60) - 30;
    const p = [x, DECK + 0.05, v.dir > 0 ? 1.7 : -1.7];
    return v.k === 'bus' ? <Bus key={i} p={p} dir={v.dir} color={v.c} /> : <Car key={i} p={p} dir={v.dir} color={v.c} taxi={v.taxi} />;
  });
}
const AZ_TRAFFIC = [
  { k: 'car', c: '#3b7dbd', dir: 1, v: 3.4, x0: -22 }, { k: 'car', c: '#d9a441', dir: 1, v: 3.0, x0: -3 }, { k: 'car', c: '#b7433a', dir: 1, v: 3.6, x0: 15 },
  { k: 'car', c: '#5b9a63', dir: -1, v: 3.2, x0: 20 }, { k: 'car', c: '#e9e1c6', dir: -1, v: 3.5, x0: 2 }, { k: 'car', c: '#7a5ea8', dir: -1, v: 3.1, x0: -16 },
];
const LONDON_TRAFFIC = [
  { k: 'bus', c: '#c8312e', dir: 1, v: 3.0, x0: -24 }, { k: 'bus', c: '#c8312e', dir: 1, v: 2.8, x0: -6 }, { k: 'car', c: '#26262a', dir: 1, v: 3.2, x0: 10, taxi: true },
  { k: 'bus', c: '#c8312e', dir: -1, v: 3.0, x0: 22 }, { k: 'car', c: '#26262a', dir: -1, v: 3.3, x0: 5, taxi: true }, { k: 'bus', c: '#c8312e', dir: -1, v: 2.9, x0: -14 },
];

// ================= Lake Havasu, Arizona =================
const azScatter = memo('azscatter', () => {
  const r = rngFrom('azs'), cac = [], rock = [], house = [];
  for (let i = 0; i < 34; i++) { const s = r() < 0.5 ? -1 : 1, x = s * (17 + r() * 60), z = -70 + r() * 110; if (Math.abs(z) < 5.5 && Math.abs(x) > 26) continue; if (Math.abs(x) < 20 && Math.abs(z) < 7) continue; cac.push({ x, z, s: 0.7 + r() * 0.9 }); }
  for (let i = 0; i < 20; i++) { const s = r() < 0.5 ? -1 : 1, x = s * (17 + r() * 60), z = -60 + r() * 100; if (Math.abs(z) < 5.5 && Math.abs(x) > 26) continue; rock.push({ x, z, s: 0.5 + r() * 0.9 }); }
  for (let i = 0; i < 12; i++) { const s = i % 2 ? -1 : 1, x = s * (36 + r() * 40), z = -90 + r() * 70; house.push({ x, z, w: 6 + r() * 4, h: 3 + r() * 2, d: 5 + r() * 3, c: ['#e9d8b4', '#d9b88c', '#efe3c8'][i % 3] }); }
  return { cac, rock, house };
});
export function Arizona({ t, X, moodSky, showPlaque = true, tint }) {
  const sc = azScatter;
  return (<group position={[X, 0, 0]}>
    <Sky top={moodSky[0]} mid={moodSky[1]} bot={moodSky[2]} />
    <Mountains z={-125} />
    {sc.house.map((h, i) => (<group key={i} position={[h.x, 5.4, h.z]}>
      <Box w={h.w} h={h.h} d={h.d} mat={C(h.c)} p={[0, h.h / 2, 0]} /><Box w={h.w + 0.6} h={0.4} d={h.d + 0.6} mat={C('#a2553d')} p={[0, h.h + 0.2, 0]} /></group>))}
    <Banks style="slope" />
    <Water t={t} />
    <Roads />
    <Bridge />
    {showPlaque && <Plaque p={[0, 4.15, 4.1]} lines={['LAKE HAVASU CITY', 'ARIZONA']} w={5.2} h={1.3} bg="#3f4a43" size={46} />}
    <Traffic t={t} list={AZ_TRAFFIC} />
    {sc.cac.map((c, i) => <Cactus key={i} p={[c.x, groundY(c.x), c.z]} s={c.s} arm={i % 3 ? 1 : 0} />)}
    {sc.rock.map((c, i) => <Rock key={i} p={[c.x, groundY(c.x) + 0.2, c.z]} s={c.s} />)}
    <Part geo={G.sph(1.6, 14)} mat={M('sand', 1, 1)} p={[-2.4, -0.4, 28]} s={[1, 0.38, 0.8]} /><Cactus p={[-2.4, 0.25, 28]} s={0.8} />
    <Rock p={[-1.2, 0.1, 28.6]} s={0.5} />
    <mesh position={[0, 0.02, 0]} />
  </group>);
}
// street sign mounted on the parapet (used in the final location shots)
export function BlvdSign({ X }) {
  return <group position={[X, 0, 0]}><SignPost p={[-9.5, 6.05, 3.35]} lines={['McCULLOCH BLVD']} w={4.4} h={1.0} postH={1.2} bg="#2f5d46" size={58} texW={512} texH={128} /></group>;
}

// ================= Thames, London =================
const bldg = memo('bldg', () => {
  const r = rngFrom('lon'), out = [];
  for (const s of [-1, 1]) for (let z = -90; z < 50; z += 11) { if (Math.abs(z) < 8) continue; out.push({ x: s * (23 + r() * 3), z: z + r() * 2, h: 8 + r() * 9, w: 11 + r() * 2, d: 9, s }); }
  return out;
});
export function Thames({ t, X, moodSky }) {
  return (<group position={[X, 0, 0]}>
    <Sky top={moodSky[0]} mid={moodSky[1]} bot={moodSky[2]} clouds="#d6d8d2" />
    <Banks style="wall" />
    <Water t={t} kind="thames" />
    <Roads />
    {bldg.map((b, i) => <Box key={i} w={b.w} h={b.h} d={b.d} mat={M('facade', 3, Math.max(1, b.h / 5))} p={[b.x, 5.4 + b.h / 2, b.z]} />)}
    {bldg.filter((_, i) => i % 3 === 0).map((b, i) => <Box key={'r' + i} w={b.w + 0.6} h={1.2} d={b.d + 0.6} mat={C('#6b6a72')} p={[b.x, 5.4 + b.h + 0.6, b.z]} />)}
    <Bridge />
    <Plaque p={[0, 4.15, 4.1]} lines={['LONDON BRIDGE', '1831']} w={4.4} h={1.3} bg="#4b4a46" size={54} />
    <Traffic t={t} list={LONDON_TRAFFIC} />
    {/* mooring pile in the foreground */}
    <Cyl rt={0.24} rb={0.28} h={3.6} mat={M('wood', 1, 2)} p={[-8.5, 1.0, 22.5]} seg={10} />
    <Cyl rt={0.3} rb={0.3} h={0.12} mat={C('#2d2a2c')} p={[-8.5, 2.5, 22.5]} seg={10} />
  </group>);
}
// sinking gauge + tilt level line (shot 3)
export function SinkingBits({ X, t }) {
  const gaugeLabel = signTex(['1 INCH', 'EVERY 8 YEARS'], { w: 512, h: 200, bg: '#7a2f2a', size: 60 });
  const lvl = pop(t, 14.55), lbl = pop(t, 16.0);
  return (<group position={[X, 0, 0]}>
    <Box w={0.5} h={3.6} d={0.14} mat={M('wood', 1, 3)} p={[-3.2, 1.2, 5.2]} />
    {Array.from({ length: 9 }, (_, i) => <Box key={i} w={i % 4 === 0 ? 0.5 : 0.32} h={0.04} d={0.02} mat={C(INK)} p={[-3.2, 0.2 + i * 0.32, 5.28]} ink={false} />)}
    <Box w={0.5} h={0.12} d={0.2} mat={C('#c0392b')} p={[-3.2, 1.0 - (t > 12.5 ? seg(t, 12.5, 14.2) * 0.32 : 0), 5.29]} ink={false} />
    <Box w={2.6} h={1.1} d={0.1} mat={M('wood', 1, 1)} p={[-3.2, 3.55, 5.2]} />
    <Label t={gaugeLabel} w={2.4} h={0.94} p={[-3.2, 3.55, 5.27]} />
    {lvl > 0 && <group scale={[1, lvl, 1]}>
      <Box w={40} h={0.07} d={0.07} mat={C('#c0392b')} p={[0, 6.95, 4.9]} ink={false} cast={false} />
      <Box w={0.07} h={0.7} d={0.07} mat={C('#c0392b')} p={[-19, 6.95, 4.9]} ink={false} cast={false} /><Box w={0.07} h={0.7} d={0.07} mat={C('#c0392b')} p={[19, 6.95, 4.9]} ink={false} cast={false} />
    </group>}
    {lbl > 0 && <group scale={lbl}>
      <Label t={signTex(['WEST'], { w: 256, h: 100, bg: '#2f5d46', size: 56 })} w={2.2} h={0.86} p={[-14, 8.0, 4.9]} />
      <Label t={signTex(['EAST', '-4 in'], { w: 256, h: 140, bg: '#7a2f2a', size: 52 })} w={2.2} h={1.2} p={[14, 5.55, 4.9]} />
    </group>}
  </group>);
}

// ================= shared room pieces =================
function RoomShell({ w = 11, z0 = -3, z1 = 9, wallH = 4.6, windows = [], floor = 'floorwood', wallMat = 'plaster', ceilY = 4.6, back = true }) {
  const wall = memo(`wall:${w}:${wallH}:${JSON.stringify(windows)}`, () => {
    const s = new THREE.Shape(); s.moveTo(-w / 2, 0); s.lineTo(w / 2, 0); s.lineTo(w / 2, wallH); s.lineTo(-w / 2, wallH); s.lineTo(-w / 2, 0);
    windows.forEach(([cx, y0, ww, hh]) => { const h = new THREE.Path(); h.moveTo(cx - ww / 2, y0); h.lineTo(cx + ww / 2, y0); h.lineTo(cx + ww / 2, y0 + hh); h.lineTo(cx - ww / 2, y0 + hh); h.lineTo(cx - ww / 2, y0); s.holes.push(h); });
    return new THREE.ExtrudeGeometry(s, { depth: 0.3, bevelEnabled: false });
  });
  return (<group>
    <mesh position={[0, 0, (z0 + z1) / 2]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow geometry={G.plane(w, z1 - z0)} material={M(floor, w / 3, (z1 - z0) / 3)} />
    {back && <Part geo={wall} mat={M(wallMat, 1 / 3, 1 / 3)} p={[0, 0, z0 - 0.3]} />}
    {[-1, 1].map((s) => <mesh key={s} position={[s * w / 2, wallH / 2, (z0 + z1) / 2]} rotation={[0, -s * Math.PI / 2, 0]} geometry={G.plane(z1 - z0, wallH)} material={Cd('#d9c59a')} />)}
    <mesh position={[0, ceilY, (z0 + z1) / 2]} rotation={[Math.PI / 2, 0, 0]} geometry={G.plane(w, z1 - z0)} material={C('#7a5a3e')} />
    {[-3, 0, 3].map((z) => <Box key={z} w={w} h={0.35} d={0.4} mat={M('wood', 4, 1)} p={[0, ceilY - 0.17, z]} />)}
  </group>);
}
const skyTex = memo('winsky', () => labelCanvas((ctx, W_, H) => {
  const g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#8fbfe0'); g.addColorStop(1, '#f2e6c4'); ctx.fillStyle = g; ctx.fillRect(0, 0, W_, H);
  ctx.fillStyle = '#c9a77a'; ctx.beginPath(); ctx.moveTo(0, H); ctx.lineTo(0, H * 0.62); ctx.lineTo(W_ * 0.25, H * 0.45); ctx.lineTo(W_ * 0.5, H * 0.6); ctx.lineTo(W_ * 0.75, H * 0.42); ctx.lineTo(W_, H * 0.6); ctx.lineTo(W_, H); ctx.fill();
  ctx.fillStyle = '#4f94b5'; ctx.fillRect(0, H * 0.78, W_, H * 0.22);
}, 512, 256).tex);

// ================= Common Council chamber =================
export function Chamber({ t, X }) {
  const idea = pop(t, W.idea - 0.2, 0.3) * (t < 22.4 ? 1 : 1 - seg(t, 22.4, 22.9));
  const arm = ease(seg(t, W.idea - 0.15, W.idea + 0.35));
  const armUp = 0.14 + (2.45 - 0.14) * arm * (t < 22.2 ? 1 : 1 - seg(t, 22.2, 22.8));
  const sale = pop(t, 23.2, 0.35);
  const nameplate = signTex(['I. LUCKIN'], { w: 256, h: 80, bg: '#8a6a2a', size: 40 });
  const forSale = signTex(['FOR SALE'], { w: 256, h: 140, bg: '#c0392b', size: 52, fg: '#ffffff' });
  return (<group position={[X, 0, 0]}>
    <RoomShell w={11} z0={-3} z1={9} windows={[[-3.4, 1.5, 1.7, 2.4], [3.4, 1.5, 1.7, 2.4]]} />
    <mesh position={[0, 2.7, -3.55]} geometry={G.plane(13, 6)} material={signMat(skyTex)} />
    <Box w={11} h={1.1} d={0.14} mat={M('panel', 4, 1)} p={[0, 0.55, -2.78]} />
    <Plaque p={[0, 3.55, -2.9]} lines={['COMMON COUNCIL']} w={4.2} h={0.8} bg="#6e2f2a" size={40} />
    {[-1, 1].map((s) => <Box key={s} w={0.8} h={1.1} d={0.08} mat={C(s < 0 ? '#9c7a3a' : '#5b6e8c')} p={[s * 1.9, 2.6, -2.86]} />)}
    {/* long council table */}
    <Box w={6.2} h={0.12} d={1.2} mat={M('wood', 3, 1)} p={[0, 0.64, 0.1]} />
    <Box w={6} h={0.6} d={0.1} mat={M('panel', 3, 1)} p={[0, 0.32, 0.62]} />
    {[-2.8, 2.8].map((x) => <Box key={x} w={0.12} h={0.6} d={1} mat={M('wood', 1, 1)} p={[x, 0.32, 0.1]} />)}
    {/* model of the bridge on the table + FOR SALE sign */}
    <Part geo={bridgeGeo()} mat={M('stone', 1 / 2.6 * 20, 1 / 1.6 * 20)} p={[0.4, 0.71, 0.15]} s={[0.05, 0.05, 0.05]} />
    <group position={[0.4, 0.73, 0.15]} scale={sale}>
      <Box w={0.04} h={0.6} d={0.04} mat={M('wood', 1, 1)} p={[0, 0.3, 0]} /><Box w={0.7} h={0.4} d={0.05} mat={C('#c0392b')} p={[0, 0.62, 0]} />
      <Label t={forSale} w={0.66} h={0.36} p={[0, 0.62, 0.04]} />
    </group>
    <Box w={0.6} h={0.16} d={0.12} mat={C('#8a6a2a')} p={[-0.5, 0.76, 0.58]} r={[-0.3, 0, 0]} /><Label t={nameplate} w={0.56} h={0.12} p={[-0.5, 0.765, 0.645]} r={[-0.3, 0, 0]} />
    <Person p={[0, 0, -0.9]} v="luckin" t={t} armR={armUp} phase={0.4} />
    <Person p={[-1.8, 0, -0.9]} v="councilA" t={t} phase={1.7} />
    <Person p={[1.8, 0, -0.9]} v="councilB" t={t} phase={3.1} />
    {idea > 0.01 && <group position={[0, 2.55, -0.85]} scale={idea}>
      <Sph rad={0.2} mat={new THREE.MeshBasicMaterial({ color: '#ffe066' })} />
      <Cyl rt={0.08} rb={0.1} h={0.12} mat={C('#6b6a72')} p={[0, -0.25, 0]} seg={10} />
      {Array.from({ length: 6 }, (_, i) => <Box key={i} w={0.05} h={0.2} d={0.02} mat={C('#ffd24d')} ink={false} p={[Math.cos(i * 1.047) * 0.42, Math.sin(i * 1.047) * 0.42, 0]} r={[0, 0, i * 1.047 + Math.PI / 2]} />)}
    </group>}
  </group>);
}

// ================= McCulloch's office =================
const calTex = memo('cal', () => labelCanvas((ctx, W_, H) => {
  ctx.fillStyle = '#f6f0dd'; ctx.fillRect(0, 0, W_, H); ctx.fillStyle = '#b3312c'; ctx.fillRect(0, 0, W_, 90);
  ctx.strokeStyle = INK; ctx.lineWidth = 10; ctx.strokeRect(5, 5, W_ - 10, H - 10);
  ctx.fillStyle = '#fff'; ctx.font = font(62); ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('APRIL', W_ / 2, 48);
  ctx.fillStyle = INK; ctx.font = font(220); ctx.fillText('18', W_ / 2, 230); ctx.font = font(70); ctx.fillText('1968', W_ / 2, 380);
}, 360, 440).tex);
const deskLabel = signTex(['McCULLOCH'], { w: 256, h: 80, bg: '#2f2a28', size: 40, fg: '#e0b43a' });
function Slip({ t }) {
  const lc = memo('slip', () => labelCanvas(() => {}, 512, 340));
  const ctx = lc.ctx; ctx.fillStyle = '#f7f1dc'; ctx.fillRect(0, 0, 512, 340); ctx.strokeStyle = INK; ctx.lineWidth = 10; ctx.strokeRect(5, 5, 502, 330);
  ctx.fillStyle = '#b3312c'; ctx.font = font(64); ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('BID', 256, 70);
  const txt = (t >= W.two - 0.1 ? '$2' : '') + (t >= W.four - 0.1 ? ',460' : '') + (t >= W.thousand - 0.05 ? ',000' : '');
  ctx.fillStyle = INK; ctx.font = font(txt.length > 6 ? 92 : 120); ctx.fillText(txt, 256, 220);
  lc.tex.needsUpdate = true;
  return <mesh position={[1.35, 0.675, 0.4]} rotation={[-1.1, 0, 0.05]} geometry={G.plane(0.95, 0.63)} material={memo('slipmat', () => new THREE.MeshBasicMaterial({ map: lc.tex }))} />;
}
export function Office({ t, X }) {
  const arm = (a, b) => ease(seg(t, a, b));
  const tap = Math.sin(t * 9) * 0.25;
  const brush = t > W.won - 0.2 && t < W.won + 0.5 ? 0.14 + arm(W.won - 0.2, W.won + 0.2) * 2.0 : 0.14;
  return (<group position={[X, 0, 0]}>
    <RoomShell w={11} z0={-2.5} z1={9} windows={[[2.9, 1.3, 1.9, 1.7]]} floor="floorwood" />
    <mesh position={[2.9, 2.1, -3.1]} geometry={G.plane(2.4, 2.2)} material={signMat(skyTex)} />
    <Box w={2.2} h={0.12} d={0.3} mat={M('stonePale', 1, 1)} p={[2.9, 1.25, -2.55]} />
    <Box w={11} h={1.0} d={0.12} mat={M('panel', 4, 1)} p={[0, 0.5, -2.45]} />
    {/* wall calendar */}
    <Box w={1.45} h={1.85} d={0.08} mat={C('#6b4329')} p={[-3.2, 1.85, -2.4]} />
    <Label t={{ ...calTex }.constructor === Object ? calTex : calTex} w={1.3} h={1.6} p={[-3.2, 1.85, -2.34]} />
    {/* desk */}
    <Box w={2.9} h={0.12} d={1.2} mat={M('wood', 2, 1)} p={[1.1, 0.62, 0.3]} />
    {[-1, 1].map((s) => <Box key={s} w={0.8} h={0.6} d={1.1} mat={M('panel', 1, 1)} p={[1.1 + s * 1.0, 0.3, 0.3]} />)}
    <Box w={0.36} h={0.1} d={0.08} mat={C('#2f2a28')} p={[0.2, 0.7, 0.75]} r={[-0.3, 0, 0]} /><Label t={deskLabel} w={0.32} h={0.07} p={[0.2, 0.705, 0.795]} r={[-0.3, 0, 0]} />
    <Slip t={t} />
    {/* desk lamp */}
    <Cyl rt={0.14} rb={0.16} h={0.06} mat={C('#2d4a3a')} p={[2.3, 0.71, 0.0]} seg={12} />
    <Cyl rt={0.02} h={0.55} mat={C('#2d4a3a')} p={[2.3, 1.0, 0.0]} seg={6} />
    <Part geo={G.cone(0.2, 0.25, 12)} mat={C('#2d4a3a')} p={[2.3, 1.35, 0.0]} />
    <Person p={[0.6, 0, -0.9]} v="mcculloch" t={t} armR={brush} phase={1.2} />
    <Person p={[-0.75, 0, -0.9]} v="clerk" t={t} phase={2.4} armL={-0.14 - tap * 0.2} />
  </group>);
}

// ================= Quay: numbering and shipping the blocks =================
const numTex = (n) => memo('num' + n, () => labelCanvas((ctx, W_, H) => {
  ctx.clearRect(0, 0, W_, H); ctx.fillStyle = '#f7f1dc'; ctx.font = font(86); ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.strokeStyle = INK; ctx.lineWidth = 8; ctx.strokeText(n, W_ / 2, H / 2); ctx.fillText(n, W_ / 2, H / 2);
}, 256, 140).tex);
const blockList = memo('blocks', () => {
  const r = rngFrom('blk'), out = [];
  for (const [bx, n] of [[-2.2, 3], [-0.6, 3], [1.0, 2]]) for (let row = 0; row < n; row++) for (let c = 0; c < 2; c++) out.push({ x: bx + c * 0.0 + (c ? 0.05 : -0.05), dx: c * 0.0, row, c, bx, z: c ? 0.2 : 1.0, n: String(1000 + ((r() * 9000) | 0)) });
  return out;
});
export function Quay({ t, X }) {
  const lift = ease(seg(t, 36.0, 38.8));
  const hookY = 1.1 + lift * 3.2;
  const paint = (p0) => (t > 35.6 && t < 38.8 ? 0.14 + (0.5 + 0.5 * Math.sin(t * 11 + p0)) * 1.1 : 0.14);
  const prog = seg(t, W.shipped, W.canal + 0.5);
  return (<group position={[X, 0, 0]}>
    <Sky top="#86b4d2" mid="#c8dce0" bot="#ede2c6" />
    <Mountains z={-110} colors={['#8ea3a6', '#7f9598', '#9db0b0']} h={0.8} />
    <mesh position={[0, 0, 26]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow geometry={G.plane(140, 60)} material={M('slab', 24, 10)} />
    <Box w={140} h={1.6} d={0.5} mat={M('stone', 30, 1)} p={[0, -0.6, -4]} />
    <mesh position={[0, -0.5, -40]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow geometry={G.plane(160, 70)} material={M('water', 12, 8)} />
    {[-8, -2, 4, 10, 16].map((x) => <Cyl key={x} rt={0.18} rb={0.22} h={0.5} mat={C('#2d2a2c')} p={[x, 0.25, -3.5]} seg={10} />)}
    {/* stacked granite blocks with numbers painted on as they are spoken */}
    {blockList.map((b, i) => {
      const x = b.bx, y = 0.28 + b.row * 0.58, show = t > 35.9 + (i / blockList.length) * 2.7;
      return (<group key={i} position={[x, y, b.z]}>
        <Box w={1.1} h={0.56} d={0.7} mat={M('stone', 0.45, 0.3)} />
        {show && <mesh position={[0, 0, 0.36]} geometry={G.plane(0.8, 0.44)} material={memo('nm' + b.n, () => new THREE.MeshBasicMaterial({ map: numTex(b.n), transparent: true }))} />}
      </group>);
    })}
    {/* crane lifting one block */}
    <Crane p={[-3.8, 0, -1.8]} hookY={hookY} load loadSpin={lift * 0.5} />
    <Box w={1.1} h={0.56} d={0.7} mat={M('stone', 0.45, 0.3)} p={[2.4, 0.28, -1.8]} />
    <Person p={[-1.4, 0, 2.5]} v="worker1" t={t} armR={paint(0)} phase={0.3} handR={<Box w={0.04} h={0.22} d={0.04} mat={C('#c0392b')} p={[0, -0.1, 0]} ink={false} />} />
    <Person p={[0.3, 0, 2.3]} v="worker2" t={t} armL={-paint(2)} phase={2.0} />
    <Cyl rt={0.18} rb={0.16} h={0.32} mat={C('#d9d4c0')} p={[-0.6, 0.16, 2.6]} seg={12} />
    <MapBoard p={[4.6, 0, -0.4]} prog={prog} />
    <Ship p={[16, -0.45, -11]} />
  </group>);
}

// ================= Cutaway: only the facing made the trip =================
const sectionGeo = (depth, inset = 0) => memo(`sec:${depth}:${inset}`, () => {
  const s = new THREE.Shape(); s.moveTo(-4, 0); s.lineTo(-4, 3.2); s.lineTo(4, 3.2); s.lineTo(4, 0); s.lineTo(1.6, 0); s.lineTo(1.6, 0.6); s.absellipse(0, 0.6, 1.6, 1.4, 0, Math.PI, false); s.lineTo(-1.6, 0); s.lineTo(-4, 0);
  const g = new THREE.ExtrudeGeometry(s, { depth, bevelEnabled: false }); g.translate(0, 0, -depth / 2); return g;
});
export function Cutaway({ t, X }) {
  const e = ease(seg(t, 41.6, 43.6));
  const sign = pop(t, 45.05, 0.35);
  return (<group position={[X, 0, 0]}>
    <Sky top="#7fb7dc" mid="#cfe3e2" bot="#f1e2bd" />
    <Mountains z={-110} />
    <mesh position={[0, 0, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow geometry={G.plane(160, 160)} material={M('sand', 26, 26)} />
    <mesh position={[0, 0.01, 2]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow geometry={G.plane(14, 12)} material={M('slab', 3, 3)} />
    {/* concrete core */}
    <Part geo={sectionGeo(3)} mat={M('concrete', 1 / 2, 1 / 1.6)} edges />
    {Array.from({ length: 5 }, (_, i) => <Cyl key={i} rt={0.04} h={1.2} mat={C('#6a3b2a')} p={[-3.2 + i * 1.6, 3.8, -0.8]} seg={6} ink={false} />)}
    {/* the stone facing sheet slides away */}
    <group position={[-7 * e, 1.6 * e, 5 * e]} rotation={[0, -0.9 * e, 0.12 * e]}>
      <Part geo={sectionGeo(0.3)} mat={M('stone', 1 / 2.6, 1 / 1.6)} p={[0, 0, 1.68]} edges />
    </group>
    <Box w={0.5} h={0.14} d={3.1} mat={M('stonePale', 1, 1)} p={[-3.6, 3.27, 0]} />
    <Box w={0.5} h={0.14} d={3.1} mat={M('stonePale', 1, 1)} p={[3.6, 3.27, 0]} />
    {/* crate with stencilled label */}
    <Box w={1.8} h={1.2} d={1.2} mat={M('wood', 2, 1)} p={[-4.8, 0.6, 3.0]} />
    <Label t={signTex(['FACING', 'ONLY'], { w: 256, h: 180, bg: '#e9e1c6', fg: '#2f2a28', size: 54 })} w={1.4} h={0.9} p={[-4.8, 0.62, 3.65]} />
    {sign > 0 && <group scale={sign}><SignPost p={[2.8, 0, 3.0]} lines={['CONCRETE']} w={2.6} h={0.8} postH={1.6} bg="#4b4a46" size={56} texW={384} texH={120} /></group>}
    <Person p={[5.2, 0, 2.4]} v="engineer" t={t} armL={-0.14 - ease(seg(t, W.facing - 0.3, W.facing + 0.3)) * 1.7} phase={0.8} />
  </group>);
}

// ================= Laying the foundation stone =================
export function Laying({ t, X }) {
  const drop = ease(seg(t, 47.55, 48.4));
  const y = 0.28 + (1 - drop) * 2.3;
  const banner = ease(seg(t, 50.35, 50.95));
  const clap = t > 50.5 ? Math.abs(Math.sin(t * 9)) : 0;
  return (<group position={[X, 0, 0]}>
    <Sky top="#7fb7dc" mid="#cfe3e2" bot="#f1e2bd" />
    <Mountains z={-110} />
    <mesh position={[0, 0, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow geometry={G.plane(160, 160)} material={M('sand', 26, 26)} />
    <mesh position={[0, 0.012, 2.5]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow geometry={G.plane(14, 9)} material={M('slab', 3, 2)} />
    {/* the bridge-to-be, far behind */}
    <Part geo={bridgeGeo()} mat={M('stone', 1 / 2.6, 1 / 1.6)} p={[4, 0, -18]} s={[0.7, 0.7, 0.7]} />
    {/* mortar bed + stone on a tripod chain */}
    <Box w={1.8} h={0.1} d={1.2} mat={C('#bfae8a')} p={[0, 0.05, 0]} />
    <group position={[0, y, 0]}>
      <Box w={1.5} h={0.56} d={0.9} mat={M('stonePale', 0.6, 0.35)} />
      <Label t={signTex(['1968'], { w: 256, h: 110, bg: '#a89a7a', fg: '#2f2a28', size: 70, border: '#6f6450' })} w={1.1} h={0.4} p={[0, 0, 0.46]} />
      {y > 0.4 && <Box w={0.04} h={3.4 - y} d={0.04} mat={C(INK)} p={[0, (3.4 - y) / 2 + 0.28, 0]} ink={false} />}
    </group>
    {[[-0.9, -0.8], [0.9, -0.8], [0, 0.9]].map(([x, z], i) => <Box key={i} w={0.1} h={3.5} d={0.1} mat={M('wood', 1, 2)} p={[x * 0.55, 1.7, z * 0.55]} r={[z * 0.12, 0, -x * 0.14]} />)}
    <Puff p={[-0.8, 0.1, 0.6]} k={seg(t, 48.4, 49.3)} s={1.2} /><Puff p={[0.9, 0.1, 0.6]} k={seg(t, 48.45, 49.4)} s={1.1} /><Puff p={[0, 0.1, 0.9]} k={seg(t, 48.4, 49.2)} s={1.0} />
    <Person p={[-1.6, 0, 0.6]} v="mayor" t={t} armR={t > 48.4 && t < 50 ? 0.9 + Math.sin(t * 7) * 0.5 : 0.14} phase={0.5} handR={<Box w={0.06} h={0.24} d={0.04} mat={C('#c9c4b0')} p={[0, -0.08, 0]} ink={false} />} />
    <Person p={[-3.0, 0, 0.5]} v="clerk" t={t} phase={2.2} />
    {/* banner on two poles */}
    {[2.4, 6.6].map((x) => <Box key={x} w={0.14} h={5.2} d={0.14} mat={M('wood', 1, 3)} p={[x, 2.6, -0.6]} />)}
    <group position={[4.5, 5.0, -0.5]} scale={[1, Math.max(0.001, banner), 1]}>
      <mesh position={[0, -0.8, 0]} geometry={G.plane(4.0, 1.6)} material={signMat(signTex(['1971', 'REDEDICATED'], { w: 512, h: 220, bg: '#b3312c', fg: '#f7f1dc', size: 96 }))} />
    </group>
    {Array.from({ length: 7 }, (_, i) => <Part key={i} geo={G.cone(0.2, 0.4, 3)} mat={C(['#e0b43a', '#b3312c', '#2f5d46'][i % 3])} p={[2.5 + i * 0.68, 5.0 - Math.sin((i / 6) * Math.PI) * 0.4, -0.5]} r={[0, 0, Math.PI]} ink={false} cast={false} />)}
    <Person p={[3.3, 0, 1.4]} v="crowd1" t={t} armL={-0.14 - clap * 1.9} armR={0.14 + clap * 1.9} phase={0.2} />
    <Person p={[4.5, 0, 1.0]} v="crowd2" t={t} armL={-0.14 - clap * 1.8} armR={0.14 + clap * 1.8} phase={1.4} />
    <Person p={[5.7, 0, 1.5]} v="crowd3" t={t} armL={-0.14 - clap * 1.9} armR={0.14 + clap * 1.9} phase={2.6} />
  </group>);
}
