// Real timings measured from the recorded voice-over (voiceover_original.wav, 62.18 s).
export const FPS = 30;
export const DURATION_S = 62.4;
export const DURATION = Math.round(DURATION_S * FPS); // 1872 frames

// sentence_times.json equivalent: [start, end] of every sentence, seconds.
export const SENTENCES = [
  [0.06, 6.15],   // 1  In 1968, London sold its bridge ... Arizona desert.
  [6.21, 8.64],   // 2a Rennie's bridge opened in 1831.
  [8.68, 11.76],  // 2b By the 1960s, the traffic was too heavy for it.
  [11.9, 14.28],  // 3a It sank an inch every eight years.
  [14.43, 18.32], // 3b By 1924, one side sat three or four inches lower.
  [18.41, 23.69], // 4  But a councillor, Ivan Luckin ... sell it.
  [23.7, 32.35],  // 5  Then, on April 18, 1968 ... $2,460,000.
  [32.5, 35.21],  // 6a The catch: it had to travel in pieces.
  [35.36, 40.58], // 6b Workers numbered 10,276 blocks ... Panama Canal.
  [40.78, 43.12], // 7a You see, only the stone facing made the trip.
  [43.31, 45.92], // 7b Underneath, the Arizona bridge is concrete.
  [46.1, 49.96],  // 8a London's Lord Mayor relaid the foundation stone in 1968.
  [50.13, 53.09], // 8b It was rededicated in October 1971.
  [53.29, 57.99], // 9  So today, stones that crossed the Thames ... Arizona.
  [58.12, 59.98], // 10a London Bridge never fell down.
  [60.23, 62.05], // 10b Its stones just moved to Arizona.
];

// One CUTS array: shot starts taken from real sentence starts (last = end of video).
export const CUTS = [0, 6.2, 11.85, 18.4, 23.7, 32.45, 40.7, 46.05, 53.25, 58.1, DURATION_S];

// Key words (seconds), used to tie camera and on-screen events to the voice.
export const W = {
  sold: 1.93, desert: 5.72,
  opened: 6.97, y1831: 7.53, traffic: 10.14, heavy: 11.04,
  sinking: 12.06, inch: 12.57, eight: 13.46, years: 13.69,
  y1924: 14.55, side: 16.07, lower: 17.89,
  councillor: 18.57, idea: 20.57, knocking: 21.97, sell: 23.46,
  april: 24.41, y1968: 25.25, chainsaw: 26.51, robert: 27.54, won: 28.7,
  two: 29.44, million: 29.75, four: 30.17, sixty: 30.83, thousand: 31.42, dollars: 31.82,
  catch: 32.62, travel: 33.89, pieces: 34.35,
  workers: 35.36, numbered: 35.76, blocks: 38.24, shipped: 38.9, panama: 39.69, canal: 40.11,
  yousee: 40.78, facing: 42.16, trek: 42.86, underneath: 43.31, concrete: 45.2,
  lord: 46.55, foundation: 47.71, stone: 48.28, y68b: 48.85,
  rededicated: 50.4, october: 51.34, y1971: 51.87,
  today: 53.54, stones: 54.17, thames: 55.17, traffic2: 55.89, canal2: 56.75, arizona: 57.31,
  london: 58.12, fell: 59.31, down: 59.58, its: 60.23, moved: 61.12, arizona2: 61.44,
};
