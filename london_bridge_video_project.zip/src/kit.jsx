import React from 'react';
import * as THREE from 'three';
import { mergeVertices } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

export const INK = '#351f22';
export const CREAM = '#f3e6c8';

// ---------- deterministic random ----------
export function rngFrom(seed) {
  let a = (typeof seed === 'string' ? [...seed].reduce((s, c) => (s * 31 + c.charCodeAt(0)) >>> 0, 7) : seed) >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const cache = new Map();
export const memo = (k, f) => { if (!cache.has(k)) cache.set(k, f()); return cache.get(k); };

// ---------- 3 band toon gradient ----------
export const gradient = memo('grad', () => {
  const d = new Uint8Array([120, 120, 120, 255, 190, 190, 190, 255, 255, 255, 255, 255]);
  const t = new THREE.DataTexture(d, 3, 1, THREE.RGBAFormat);
  t.minFilter = t.magFilter = THREE.NearestFilter; t.needsUpdate = true; return t;
});

// ---------- painted canvas textures (flat colour + wear) ----------
function canvasTex(w, h, draw, seed) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const ctx = c.getContext('2d');
  draw(ctx, w, h, rngFrom(seed));
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = 4;
  return t;
}
function wear(ctx, w, h, r, { stains = 5, chips = 40, scratches = 20, dark = '#2a1d14', light = '#f4ead2' } = {}) {
  ctx.save();
  for (let i = 0; i < stains; i++) { // long drip stains
    const x = r() * w, y = r() * h * 0.6, ww = 6 + r() * 26, hh = 40 + r() * 140;
    const g = ctx.createLinearGradient(0, y, 0, y + hh); g.addColorStop(0, 'rgba(40,28,18,0.0)'); g.addColorStop(0.3, 'rgba(40,28,18,0.18)'); g.addColorStop(1, 'rgba(40,28,18,0)');
    ctx.fillStyle = g; ctx.fillRect(x, y, ww, hh);
  }
  for (let i = 0; i < chips; i++) { // chips: little light polygons
    const x = r() * w, y = r() * h, s = 2 + r() * 6;
    ctx.fillStyle = r() > 0.5 ? light : dark; ctx.globalAlpha = 0.45;
    ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + s, y + r() * s); ctx.lineTo(x + r() * s, y + s); ctx.closePath(); ctx.fill();
  }
  ctx.globalAlpha = 0.35; ctx.lineWidth = 1;
  for (let i = 0; i < scratches; i++) {
    const x = r() * w, y = r() * h, l = 8 + r() * 40, a = r() * Math.PI;
    ctx.strokeStyle = r() > 0.5 ? light : dark;
    ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); ctx.stroke();
  }
  ctx.restore();
}
const speckle = (ctx, w, h, r, n, cols) => { for (let i = 0; i < n; i++) { ctx.fillStyle = cols[(r() * cols.length) | 0]; ctx.globalAlpha = 0.5; ctx.fillRect(r() * w, r() * h, 1 + r() * 2, 1 + r() * 2); } ctx.globalAlpha = 1; };

const MAKE = {
  stone: () => canvasTex(512, 512, (ctx, w, h, r) => {
    const pal = ['#bdb2a0', '#aea493', '#c9bfab', '#b5aa97', '#a59b8a'];
    ctx.fillStyle = '#7d7260'; ctx.fillRect(0, 0, w, h);
    const rows = 5, rh = h / rows;
    for (let j = 0; j < rows; j++) {
      let x = -((j % 2) * 90), k = 0;
      while (x < w) {
        const bw = 150 + r() * 120; ctx.fillStyle = pal[(r() * pal.length) | 0];
        ctx.fillRect(x + 2, j * rh + 2, bw - 4, rh - 4);
        x += bw; k++;
      }
    }
    speckle(ctx, w, h, r, 700, ['#8d8372', '#d9cfba', '#988d7b']); wear(ctx, w, h, r, { stains: 8, chips: 70, scratches: 30 });
  }, 'stone'),
  stonePale: () => canvasTex(512, 512, (ctx, w, h, r) => {
    const pal = ['#d6cbb4', '#cfc3aa', '#dcd1bb', '#c8bca4'];
    ctx.fillStyle = '#9b907a'; ctx.fillRect(0, 0, w, h);
    const rows = 4, rh = h / rows;
    for (let j = 0; j < rows; j++) { let x = -((j % 2) * 120); while (x < w) { const bw = 190 + r() * 120; ctx.fillStyle = pal[(r() * pal.length) | 0]; ctx.fillRect(x + 2, j * rh + 2, bw - 4, rh - 4); x += bw; } }
    speckle(ctx, w, h, r, 500, ['#a99d86', '#efe6d2']); wear(ctx, w, h, r, { stains: 5, chips: 45, scratches: 20 });
  }, 'stonePale'),
  brick: () => canvasTex(512, 512, (ctx, w, h, r) => {
    const pal = ['#a4543a', '#94472f', '#b06046', '#8a4430'];
    ctx.fillStyle = '#5b3a2c'; ctx.fillRect(0, 0, w, h);
    const bh = 32, bw = 64;
    for (let j = 0; j < h / bh; j++) for (let i = -1; i < w / bw + 1; i++) { ctx.fillStyle = pal[(r() * 4) | 0]; ctx.fillRect(i * bw + (j % 2) * 32 + 2, j * bh + 2, bw - 4, bh - 4); }
    speckle(ctx, w, h, r, 500, ['#6a3a28', '#c47a5c']); wear(ctx, w, h, r, { stains: 6, chips: 40 });
  }, 'brick'),
  wood: () => canvasTex(512, 512, (ctx, w, h, r) => {
    const pal = ['#8a5a36', '#7d4f2e', '#94623c', '#86553a'];
    for (let j = 0; j < 8; j++) { ctx.fillStyle = pal[(r() * 4) | 0]; ctx.fillRect(0, j * 64, w, 62); ctx.fillStyle = '#3d2616'; ctx.fillRect(0, j * 64 + 62, w, 2); }
    ctx.strokeStyle = 'rgba(50,30,18,0.35)'; for (let i = 0; i < 60; i++) { const y = r() * h, x = r() * w; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 40 + r() * 120, y + (r() - 0.5) * 3); ctx.stroke(); }
    wear(ctx, w, h, r, { stains: 3, chips: 20, scratches: 30 });
  }, 'wood'),
  floorwood: () => canvasTex(512, 512, (ctx, w, h, r) => {
    const pal = ['#9a6a40', '#8e5f38', '#a4744a', '#935f3a'];
    for (let i = 0; i < 8; i++) { ctx.fillStyle = pal[(r() * 4) | 0]; ctx.fillRect(i * 64, 0, 62, h); ctx.fillStyle = '#4a2f1b'; ctx.fillRect(i * 64 + 62, 0, 2, h); }
    for (let i = 0; i < 8; i++) { const y = r() * h; ctx.fillStyle = '#4a2f1b'; ctx.fillRect(i * 64, y, 62, 2); }
    wear(ctx, w, h, r, { stains: 4, chips: 30, scratches: 40 });
  }, 'floorwood'),
  sand: () => canvasTex(512, 512, (ctx, w, h, r) => {
    ctx.fillStyle = '#e0c28c'; ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = 'rgba(176,134,84,0.45)'; ctx.lineWidth = 3;
    for (let i = 0; i < 26; i++) { const y = r() * h, x = r() * w; ctx.beginPath(); ctx.arc(x, y, 30 + r() * 60, Math.PI * 1.1, Math.PI * 1.9); ctx.stroke(); }
    speckle(ctx, w, h, r, 900, ['#c49a60', '#f3dcae', '#b58a52']);
  }, 'sand'),
  water: () => canvasTex(512, 512, (ctx, w, h, r) => {
    ctx.fillStyle = '#4f94b5'; ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = 'rgba(214,240,248,0.55)'; ctx.lineWidth = 3;
    for (let i = 0; i < 60; i++) { const y = r() * h, x = r() * w, l = 20 + r() * 50; ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x + l / 2, y - 5, x + l, y); ctx.stroke(); }
    ctx.strokeStyle = 'rgba(30,80,110,0.35)'; for (let i = 0; i < 40; i++) { const y = r() * h, x = r() * w; ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x + 20, y + 5, x + 40, y); ctx.stroke(); }
  }, 'water'),
  thames: () => canvasTex(512, 512, (ctx, w, h, r) => {
    ctx.fillStyle = '#7b7f6d'; ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = 'rgba(200,205,190,0.45)'; ctx.lineWidth = 3;
    for (let i = 0; i < 60; i++) { const y = r() * h, x = r() * w, l = 20 + r() * 50; ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x + l / 2, y - 5, x + l, y); ctx.stroke(); }
    ctx.strokeStyle = 'rgba(60,62,50,0.4)'; for (let i = 0; i < 40; i++) { const y = r() * h, x = r() * w; ctx.beginPath(); ctx.moveTo(x, y); ctx.quadraticCurveTo(x + 20, y + 5, x + 40, y); ctx.stroke(); }
  }, 'thames'),
  concrete: () => canvasTex(512, 512, (ctx, w, h, r) => {
    ctx.fillStyle = '#9a9a94'; ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#8a8a84'; for (let i = 0; i < 6; i++) ctx.fillRect(0, i * 85, w, 3);
    ctx.fillStyle = '#7d7d78'; for (let i = 0; i < 4; i++) ctx.fillRect(i * 128, 0, 3, h);
    ctx.fillStyle = '#74746f'; for (let j = 0; j < 6; j++) for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.arc(i * 128 + 20, j * 85 + 14, 4, 0, 7); ctx.fill(); }
    speckle(ctx, w, h, r, 800, ['#7a7a75', '#b0b0a8']); wear(ctx, w, h, r, { stains: 9, chips: 60, scratches: 25 });
  }, 'concrete'),
  plaster: () => canvasTex(512, 512, (ctx, w, h, r) => {
    ctx.fillStyle = '#e4d3ac'; ctx.fillRect(0, 0, w, h); speckle(ctx, w, h, r, 500, ['#cdb98c', '#f2e6c6']); wear(ctx, w, h, r, { stains: 7, chips: 30, scratches: 14 });
  }, 'plaster'),
  panel: () => canvasTex(512, 512, (ctx, w, h, r) => {
    ctx.fillStyle = '#6b4329'; ctx.fillRect(0, 0, w, h);
    for (let i = 0; i < 4; i++) { ctx.fillStyle = '#7c4f30'; ctx.fillRect(i * 128 + 12, 16, 104, h - 32); ctx.strokeStyle = '#3d2616'; ctx.lineWidth = 4; ctx.strokeRect(i * 128 + 12, 16, 104, h - 32); }
    wear(ctx, w, h, r, { stains: 3, chips: 20, scratches: 30 });
  }, 'panel'),
  asphalt: () => canvasTex(512, 512, (ctx, w, h, r) => {
    ctx.fillStyle = '#57575a'; ctx.fillRect(0, 0, w, h); speckle(ctx, w, h, r, 1200, ['#737377', '#3f3f42', '#8a8a8c']); wear(ctx, w, h, r, { stains: 3, chips: 20, scratches: 8 });
  }, 'asphalt'),
  slab: () => canvasTex(512, 512, (ctx, w, h, r) => {
    ctx.fillStyle = '#a9a79d'; ctx.fillRect(0, 0, w, h);
    ctx.fillStyle = '#6f6d64'; for (let i = 0; i < 4; i++) { ctx.fillRect(0, i * 128, w, 3); ctx.fillRect(i * 128 + (i % 2) * 40, 0, 3, h); }
    speckle(ctx, w, h, r, 600, ['#8d8b82', '#c8c6bb']); wear(ctx, w, h, r, { stains: 5, chips: 40, scratches: 20 });
  }, 'slab'),
  facade: () => canvasTex(512, 512, (ctx, w, h, r) => { // Victorian facade with window grid
    ctx.fillStyle = '#b58f6c'; ctx.fillRect(0, 0, w, h); speckle(ctx, w, h, r, 500, ['#9a7556', '#cfa985']);
    for (let j = 0; j < 4; j++) for (let i = 0; i < 4; i++) {
      const x = i * 128 + 30, y = j * 128 + 24;
      ctx.fillStyle = '#2f3a46'; ctx.fillRect(x, y, 68, 84); ctx.fillStyle = '#e9dcc0'; ctx.fillRect(x - 6, y - 8, 80, 8); ctx.fillRect(x - 6, y + 84, 80, 8);
      ctx.fillStyle = '#e9dcc0'; ctx.fillRect(x + 32, y, 4, 84); ctx.fillRect(x, y + 40, 68, 4);
    }
    wear(ctx, w, h, r, { stains: 6, chips: 25, scratches: 10 });
  }, 'facade'),
};
export function tex(name, rx = 1, ry = 1) {
  const base = memo('tex:' + name, MAKE[name]);
  return memo(`tex:${name}:${rx}:${ry}`, () => { const t = base.clone(); t.repeat.set(rx, ry); t.needsUpdate = true; return t; });
}

// ---------- materials ----------
export function M(name, rx = 1, ry = 1, color = '#ffffff') {
  return memo(`m:${name}:${rx}:${ry}:${color}`, () => new THREE.MeshToonMaterial({ map: tex(name, rx, ry), color, gradientMap: gradient }));
}
export function C(hex) {
  return memo('c:' + hex, () => new THREE.MeshToonMaterial({ color: hex, gradientMap: gradient }));
}
export function Cd(hex) { // double sided flat colour (cloth, thin things)
  return memo('cd:' + hex, () => new THREE.MeshToonMaterial({ color: hex, gradientMap: gradient, side: THREE.DoubleSide }));
}

// ---------- text on canvas (in-world labels) ----------
export function labelCanvas(draw, w, h) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const ctx = c.getContext('2d'); draw(ctx, w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return { canvas: c, ctx, tex: t };
}
const FONT = '"Trebuchet MS", "DejaVu Sans", Arial, sans-serif';
export const font = (px, bold = true) => `${bold ? 'bold ' : ''}${px}px ${FONT}`;
// painted sign: coloured board, ink border, cream letters
export function signTex(lines, { w = 512, h = 160, bg = '#2f5d46', fg = CREAM, size = 60, border = INK, key = '' } = {}) {
  return memo(`sign:${lines.join('|')}:${w}:${h}:${bg}:${key}`, () => {
    const { tex: t } = labelCanvas((ctx, W, H) => {
      ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H);
      ctx.strokeStyle = border; ctx.lineWidth = 12; ctx.strokeRect(6, 6, W - 12, H - 12);
      ctx.strokeStyle = fg; ctx.lineWidth = 3; ctx.strokeRect(20, 20, W - 40, H - 40);
      ctx.fillStyle = fg; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      const n = lines.length; const px = n > 1 ? size * 0.82 : size;
      lines.forEach((ln, i) => { ctx.font = font(px); ctx.fillText(ln, W / 2, H / 2 + (i - (n - 1) / 2) * px * 1.12); });
    }, w, h);
    return t;
  });
}
export const signMat = (t) => memo('signmat:' + t.uuid, () => new THREE.MeshToonMaterial({ map: t, gradientMap: gradient }));

// ---------- outline (inverted hull, constant pixel width) ----------
export const OUTLINE = memo('outline', () => new THREE.ShaderMaterial({
  uniforms: { uPx: { value: 3.2 }, uView: { value: new THREE.Vector2(720, 1280) }, uColor: { value: new THREE.Color(INK) } },
  vertexShader: `uniform float uPx; uniform vec2 uView;
    void main(){
      vec4 p = projectionMatrix * modelViewMatrix * vec4(position,1.0);
      vec3 n = normalize(normalMatrix * normal);
      vec2 d = (projectionMatrix * vec4(n,0.0)).xy;
      float l = length(d); if(l > 0.0001) d /= l;
      p.xy += d * (uPx * 2.0 / uView) * p.w;
      gl_Position = p;
    }`,
  fragmentShader: `uniform vec3 uColor; void main(){ gl_FragColor = vec4(uColor,1.0); }`,
  side: THREE.BackSide, fog: false,
}));
export const EDGE = memo('edge', () => new THREE.LineBasicMaterial({ color: INK }));
const outlineCache = new WeakMap();
export function outlineGeo(g) {
  if (!outlineCache.has(g)) {
    const c = g.clone(); c.deleteAttribute('normal'); if (c.getAttribute('uv')) c.deleteAttribute('uv'); if (c.getAttribute('uv1')) c.deleteAttribute('uv1');
    const m = mergeVertices(c, 1e-3); m.computeVertexNormals(); outlineCache.set(g, m);
  }
  return outlineCache.get(g);
}
const edgeCache = new WeakMap();
export function edgeGeo(g) { if (!edgeCache.has(g)) edgeCache.set(g, new THREE.EdgesGeometry(g, 30)); return edgeCache.get(g); }

// ---------- cached geometries ----------
export const G = {
  box: (w, h, d) => memo(`g:b:${w}:${h}:${d}`, () => new THREE.BoxGeometry(w, h, d)),
  cyl: (rt, rb, h, s = 20) => memo(`g:c:${rt}:${rb}:${h}:${s}`, () => new THREE.CylinderGeometry(rt, rb, h, s)),
  sph: (r, s = 20) => memo(`g:s:${r}:${s}`, () => new THREE.SphereGeometry(r, s, s * 0.7)),
  cone: (r, h, s = 12) => memo(`g:k:${r}:${h}:${s}`, () => new THREE.ConeGeometry(r, h, s)),
  plane: (w, h) => memo(`g:p:${w}:${h}`, () => new THREE.PlaneGeometry(w, h)),
};

// A part: toon mesh + inverted-hull ink outline (+ optional edge lines)
export function Part({ geo, mat, p = [0, 0, 0], r = [0, 0, 0], s = [1, 1, 1], ink = true, edges = false, cast = true, recv = true, children }) {
  const og = ink ? outlineGeo(geo) : null;
  return (
    <mesh geometry={geo} material={mat} position={p} rotation={r} scale={s} castShadow={cast} receiveShadow={recv}>
      {ink && <mesh geometry={og} material={OUTLINE} />}
      {edges && <lineSegments geometry={edgeGeo(geo)} material={EDGE} />}
      {children}
    </mesh>
  );
}
export const Box = ({ w, h, d, mat, ...o }) => <Part geo={G.box(w, h, d)} mat={mat} {...o} />;
export const Cyl = ({ rt, rb = rt, h, seg = 20, mat, ...o }) => <Part geo={G.cyl(rt, rb, h, seg)} mat={mat} {...o} />;
export const Sph = ({ rad, seg = 20, mat, ...o }) => <Part geo={G.sph(rad, seg)} mat={mat} {...o} />;

// flat plane label (no outline)
export function Label({ t, w, h, p, r = [0, 0, 0], lit = false }) {
  return <mesh position={p} rotation={r} geometry={G.plane(w, h)} material={signMat(t)} />;
}
export function Ground({ w, d, matName, rx, ry, y = 0, p = [0, 0, 0] }) {
  return <mesh position={[p[0], y, p[2]]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow geometry={G.plane(w, d)} material={M(matName, rx ?? w / 6, ry ?? d / 6)} />;
}
export const clamp = (x, a, b) => Math.min(b, Math.max(a, x));
export const ease = (x) => { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); };
export const seg = (t, a, b) => clamp((t - a) / (b - a), 0, 1); // progress of t between a and b
