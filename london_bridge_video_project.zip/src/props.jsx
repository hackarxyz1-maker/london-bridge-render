import React from 'react';
import * as THREE from 'three';
import { Box, Cyl, Sph, Part, M, C, Cd, G, memo, signTex, Label, clamp, ease, seg, labelCanvas, font, INK, CREAM, tex, rngFrom } from './kit.jsx';

export const DECK = 5.4;          // road level on the bridge
export const groundY = (x) => clamp((Math.abs(x) - 15.2) / 12.8, 0, 1) * 5.4; // sand bank profile

// ---------- the five arch bridge (stone-faced) ----------
const archCenters = [-12.8, -6.4, 0, 6.4, 12.8];
export function bridgeGeo(L = 27, depth = 8) {
  return memo(`bridge:${L}:${depth}`, () => {
    const s = new THREE.Shape();
    s.moveTo(-L, 0); s.lineTo(-L, 5.1); s.lineTo(L, 5.1); s.lineTo(L, 0);
    for (let i = archCenters.length - 1; i >= 0; i--) {
      const cx = archCenters[i];
      s.lineTo(cx + 2.4, 0); s.lineTo(cx + 2.4, 1.2); s.absellipse(cx, 1.2, 2.4, 2.0, 0, Math.PI, false); s.lineTo(cx - 2.4, 0);
    }
    s.lineTo(-L, 0);
    const g = new THREE.ExtrudeGeometry(s, { depth, bevelEnabled: false, steps: 1 });
    g.translate(0, 0, -depth / 2); return g;
  });
}
export function Lamp({ p }) {
  return (<group position={p}>
    <Cyl rt={0.07} rb={0.1} h={2.5} mat={C('#2d2a2c')} p={[0, 1.25, 0]} seg={8} />
    <Box w={0.38} h={0.5} d={0.38} mat={C('#ffe7a4')} p={[0, 2.7, 0]} />
    <Cyl rt={0.02} rb={0.26} h={0.28} mat={C('#2d2a2c')} p={[0, 3.08, 0]} seg={8} />
  </group>);
}
export function Bridge({ tilt = 0, stone = 'stone', lamps = true }) {
  const sm = M(stone, 1 / 2.6, 1 / 1.6), pale = M('stonePale', 14, 1.3);
  return (
    <group rotation={[0, 0, tilt]}>
      <Part geo={bridgeGeo()} mat={sm} edges />
      <Box w={54.6} h={0.3} d={8.8} mat={M('stonePale', 18, 3)} p={[0, 5.25, 0]} />
      {[-1, 1].map((s) => <Box key={s} w={54} h={0.65} d={0.5} mat={pale} p={[0, 5.73, s * 3.8]} />)}
      <mesh position={[0, DECK + 0.015, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow geometry={G.plane(54, 7.1)} material={M('asphalt', 9, 1.2)} />
      {Array.from({ length: 9 }, (_, i) => <Box key={i} w={2.2} h={0.02} d={0.14} mat={C(CREAM)} p={[-21 + i * 5.2, DECK + 0.03, 0]} ink={false} cast={false} />)}
      {lamps && [-22, -11, 0, 11, 22].map((x) => [-1, 1].map((s) => <Lamp key={x + ':' + s} p={[x, DECK, s * 3.8]} />))}
    </group>
  );
}
export function Banks({ style = 'slope', sand = 'sand' }) {
  const th = Math.atan2(5.4, 12.8), len = Math.hypot(12.8, 5.4);
  return (
    <group>
      {[-1, 1].map((s) => (
        <group key={s} scale={[s, 1, 1]}>
          {style === 'slope' ? (<>
            <group position={[21.6, 2.7, 0]} rotation={[0, 0, th]}><mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow geometry={G.plane(len, 220)} material={M(sand, len / 6, 36)} /></group>
            <mesh position={[69, 5.4, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow geometry={G.plane(82, 220)} material={M(sand, 14, 36)} />
          </>) : (<>
            <mesh position={[62.6, 2.2, 0]} receiveShadow geometry={G.box(94.8, 7.4, 220)} material={M('stone', 30, 2)} />
            <mesh position={[62.6, 5.41, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow geometry={G.plane(94.8, 220)} material={M('slab', 16, 36)} />
          </>)}
        </group>
      ))}
    </group>
  );
}
export function Water({ t, kind = 'water', w = 31, d = 220 }) {
  const m = M(kind, 7, 48); m.map.offset.set(0, -t * 0.1);
  return <mesh position={[0, 0, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow geometry={G.plane(w, d)} material={m} />;
}
// road continuing over the bank plateau
export function Roads() {
  return [-1, 1].map((s) => <mesh key={s} position={[s * 68, 5.42, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow geometry={G.plane(82, 7.1)} material={M('asphalt', 14, 1.2)} />);
}

// ---------- vehicles ----------
const wheel = (p) => <Cyl rt={0.38} h={0.34} mat={C('#2a2628')} p={p} r={[Math.PI / 2, 0, 0]} seg={14} />;
export function Bus({ p, dir = 1, color = '#c8312e' }) {
  return (<group position={p} scale={[dir, 1, 1]}>
    <Box w={4.4} h={1.3} d={2} mat={C(color)} p={[0, 0.95, 0]} />
    <Box w={4.2} h={1.15} d={1.9} mat={C(color)} p={[0, 2.2, 0]} />
    {[-1, 1].map((s) => (<React.Fragment key={s}>
      <Box w={3.7} h={0.5} d={0.05} mat={C('#e9e1c6')} p={[0, 1.1, s * 1.02]} ink={false} />
      <Box w={3.8} h={0.5} d={0.05} mat={C('#e9e1c6')} p={[0, 2.25, s * 0.97]} ink={false} />
    </React.Fragment>))}
    <Box w={4.25} h={0.12} d={1.92} mat={C('#e9e1c6')} p={[0, 2.82, 0]} ink={false} />
    {[[-1.4, -1], [-1.4, 1], [1.4, -1], [1.4, 1]].map(([x, z], i) => <React.Fragment key={i}>{wheel([x, 0.4, z * 0.95])}</React.Fragment>)}
  </group>);
}
export function Car({ p, dir = 1, color = '#3b7dbd', taxi = false }) {
  return (<group position={p} scale={[dir, 1, 1]}>
    <Box w={3} h={0.75} d={1.4} mat={C(color)} p={[0, 0.65, 0]} />
    <Box w={1.6} h={0.62} d={1.25} mat={C(color)} p={[-0.1, 1.3, 0]} />
    {[-1, 1].map((s) => <Box key={s} w={1.3} h={0.38} d={0.05} mat={C('#cfe3ea')} p={[-0.1, 1.33, s * 0.64]} ink={false} />)}
    <Box w={0.12} h={0.2} d={0.3} mat={C('#ffe7a4')} p={[1.5, 0.78, 0.45]} ink={false} /><Box w={0.12} h={0.2} d={0.3} mat={C('#ffe7a4')} p={[1.5, 0.78, -0.45]} ink={false} />
    {taxi && <Box w={0.5} h={0.18} d={0.3} mat={C('#ffe7a4')} p={[-0.1, 1.72, 0]} />}
    {[[-0.95, -1], [-0.95, 1], [0.95, -1], [0.95, 1]].map(([x, z], i) => <React.Fragment key={i}>{<Cyl rt={0.3} h={0.28} mat={C('#2a2628')} p={[x, 0.3, z * 0.72]} r={[Math.PI / 2, 0, 0]} seg={12} />}</React.Fragment>)}
  </group>);
}

// ---------- signs ----------
export function SignPost({ p, lines, w = 4, h = 1.3, postH = 2.4, yaw = 0, bg = '#2f5d46', size = 60, texW = 512, texH = 160 }) {
  const t = signTex(lines, { bg, size, w: texW, h: texH });
  return (<group position={p} rotation={[0, yaw, 0]}>
    {[-1, 1].map((s) => <Box key={s} w={0.16} h={postH} d={0.16} mat={M('wood', 1, 1)} p={[s * (w / 2 - 0.2), postH / 2, 0]} />)}
    <Box w={w + 0.2} h={h + 0.2} d={0.12} mat={M('wood', 2, 1)} p={[0, postH - h / 2 - 0.1, -0.02]} />
    <Label t={t} w={w} h={h} p={[0, postH - h / 2 - 0.1, 0.06]} />
  </group>);
}
export function Plaque({ p, lines, w = 3.2, h = 1.0, bg = '#4b4a46', size = 64 }) {
  return (<group position={p}>
    <Box w={w + 0.3} h={h + 0.3} d={0.12} mat={C('#8c8776')} />
    <Label t={signTex(lines, { w: 512, h: Math.round(512 * h / w), bg, size, fg: '#e8dcb8' })} w={w} h={h} p={[0, 0, 0.07]} />
  </group>);
}

// ---------- scenery ----------
export function Cactus({ p, s = 1, arm = 1 }) {
  const g = C('#5a8a4a');
  return (<group position={p} scale={s}>
    <Cyl rt={0.26} rb={0.3} h={2.6} mat={g} p={[0, 1.3, 0]} seg={12} />
    <Sph rad={0.26} mat={g} p={[0, 2.6, 0]} />
    {[1, -1].map((d, i) => (i === 0 || arm > 0) && (<group key={d}>
      <Cyl rt={0.16} h={0.8 + i * 0.2} mat={g} p={[d * 0.55, 1.2 + i * 0.3, 0]} r={[0, 0, Math.PI / 2]} seg={10} />
      <Cyl rt={0.16} h={1.0 + i * 0.3} mat={g} p={[d * 0.95, 1.7 + i * 0.3, 0]} seg={10} />
      <Sph rad={0.16} mat={g} p={[d * 0.95, 2.2 + i * 0.45, 0]} seg={10} />
    </group>))}
  </group>);
}
export function Rock({ p, s = 1, c = '#b9946a' }) {
  return <Part geo={memo('rock', () => new THREE.DodecahedronGeometry(0.7, 0))} mat={C(c)} p={p} s={[s * 1.3, s * 0.8, s]} />;
}
export function Mountains({ z = -110, colors = ['#b98e78', '#a47c6a', '#c49a80'], h = 1 }) {
  const r = rngFrom('mtn');
  return (<group>
    {Array.from({ length: 14 }, (_, i) => {
      const x = -150 + i * 23 + r() * 10, rad = 22 + r() * 16, hh = (12 + r() * 16) * h;
      return <mesh key={i} position={[x, hh / 2 - 1, z - r() * 20]} geometry={G.cone(rad, hh, 5)} material={C(colors[i % 3])} />;
    })}
  </group>);
}
export function Houses({ z = -60, x0 = -80, n = 9 }) {
  const r = rngFrom('hs');
  return Array.from({ length: n }, (_, i) => {
    const w = 6 + r() * 4, d = 5 + r() * 3, h = 3 + r() * 2;
    return (<group key={i} position={[x0 + i * 19 + r() * 6, 5.4, z - r() * 14]}>
      <Box w={w} h={h} d={d} mat={C(['#e9d8b4', '#d9b88c', '#efe3c8'][i % 3])} p={[0, h / 2, 0]} />
      <Box w={w + 0.6} h={0.4} d={d + 0.6} mat={C('#a2553d')} p={[0, h + 0.2, 0]} />
    </group>);
  });
}
export function Sky({ top = '#7fb7dc', mid = '#cfe3e2', bot = '#f1e2bd', clouds = '#ffffff' }) {
  const t = memo(`sky:${top}:${mid}:${bot}:${clouds}`, () => labelCanvas((ctx, W, H) => {
    const g = ctx.createLinearGradient(0, 0, 0, H); g.addColorStop(0, top); g.addColorStop(0.55, mid); g.addColorStop(1, bot); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    const r = rngFrom('cl'); ctx.fillStyle = clouds; ctx.globalAlpha = 0.6;
    for (let i = 0; i < 9; i++) { const x = r() * W, y = H * (0.2 + r() * 0.35), s = 22 + r() * 30; ctx.beginPath(); for (let k = 0; k < 4; k++) ctx.arc(x + k * s * 0.7, y + (k % 2) * -8, s * (0.55 + r() * 0.25), 0, 7); ctx.fill(); }
  }, 1024, 512).tex);
  return <mesh><sphereGeometry args={[260, 24, 16]} /><meshBasicMaterial map={t} side={THREE.BackSide} fog={false} /></mesh>;
}
// a puff of dust that expands and fades
export function Puff({ p, k, s = 1 }) {
  if (k <= 0 || k >= 1) return null;
  const m = memo('puff' + Math.round(k * 8), () => new THREE.MeshBasicMaterial({ color: '#efe1c3', transparent: true, opacity: 0.75 * (1 - Math.round(k * 8) / 8), depthWrite: false }));
  return <mesh position={[p[0], p[1] + k * 0.6, p[2]]} scale={s * (0.3 + k * 1.2)} geometry={G.sph(0.6, 10)} material={m} />;
}
// map board with an animated ship (progress 0..1)
export function MapBoard({ p, prog, w = 3.4, h = 2.3 }) {
  const lc = memo('mapcanvas', () => labelCanvas(() => {}, 512, 340));
  const ctx = lc.ctx, W = 512, H = 340;
  ctx.fillStyle = '#86b8cc'; ctx.fillRect(0, 0, W, H);
  const land = (pts, c = '#9aae62') => { ctx.beginPath(); pts.forEach((q, i) => (i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]))); ctx.closePath(); ctx.fillStyle = c; ctx.fill(); ctx.strokeStyle = INK; ctx.lineWidth = 4; ctx.stroke(); };
  land([[40, 60], [100, 36], [190, 44], [215, 100], [175, 150], [150, 188], [128, 176], [90, 150], [58, 110]]);
  land([[150, 196], [190, 190], [236, 226], [226, 290], [196, 326], [170, 280], [160, 232]], '#a8b86c');
  land([[392, 40], [470, 48], [492, 110], [440, 160], [396, 120]], '#c4b878');
  const route = [[420, 84], [320, 130], [220, 168], [168, 190], [140, 192], [90, 150], [74, 118]];
  ctx.setLineDash([10, 8]); ctx.strokeStyle = '#c0392b'; ctx.lineWidth = 5; ctx.beginPath(); route.forEach((q, i) => (i ? ctx.lineTo(q[0], q[1]) : ctx.moveTo(q[0], q[1]))); ctx.stroke(); ctx.setLineDash([]);
  ctx.fillStyle = INK; ctx.font = font(30); ctx.textAlign = 'center'; ctx.fillText('PANAMA CANAL', 330, 300);
  ctx.beginPath(); ctx.arc(167, 191, 9, 0, 7); ctx.fillStyle = '#ffd34d'; ctx.fill(); ctx.stroke();
  // ship marker along route
  const lens = route.slice(1).map((q, i) => Math.hypot(q[0] - route[i][0], q[1] - route[i][1])); const tot = lens.reduce((a, b) => a + b, 0);
  let d = clamp(prog, 0, 1) * tot, i = 0; while (i < lens.length - 1 && d > lens[i]) { d -= lens[i]; i++; }
  const a = route[i], b = route[i + 1], f = d / lens[i], sx = a[0] + (b[0] - a[0]) * f, sy = a[1] + (b[1] - a[1]) * f;
  ctx.fillStyle = '#2b2f36'; ctx.fillRect(sx - 14, sy - 5, 28, 10); ctx.fillStyle = '#f2ead0'; ctx.fillRect(sx - 6, sy - 12, 12, 8); ctx.strokeStyle = INK; ctx.lineWidth = 3; ctx.strokeRect(sx - 14, sy - 5, 28, 10);
  lc.tex.needsUpdate = true;
  const mat = memo('mapmat', () => new THREE.MeshToonMaterial({ map: lc.tex, gradientMap: M('stone').gradientMap }));
  return (<group position={p}>
    <Box w={w + 0.3} h={h + 0.3} d={0.12} mat={M('wood', 2, 1)} p={[0, 1.4, -0.02]} />
    <mesh position={[0, 1.4, 0.05]} geometry={G.plane(w, h)} material={mat} />
    {[-1, 1].map((s) => <Box key={s} w={0.12} h={1.0} d={0.12} mat={M('wood', 1, 1)} p={[s * (w / 2 - 0.2), 0.5, -0.1]} r={[0.12, 0, 0]} />)}
  </group>);
}
export function Ship({ p }) {
  const hull = memo('hullgeo', () => {
    const s = new THREE.Shape(); s.moveTo(-9, 0.2); s.lineTo(8, 0.2); s.lineTo(11, 2.8); s.lineTo(-9.5, 2.8); s.lineTo(-9, 0.2);
    const g = new THREE.ExtrudeGeometry(s, { depth: 4, bevelEnabled: false }); g.translate(0, 0, -2); return g;
  });
  return (<group position={p}>
    <Part geo={hull} mat={C('#2b2f36')} />
    <Box w={18.4} h={0.5} d={4.06} mat={C('#a8352c')} p={[-0.3, 0.62, 0]} />
    <Box w={6} h={1.8} d={3.2} mat={C('#efe6cc')} p={[-3, 3.7, 0]} />
    <Box w={3.2} h={1.4} d={2.6} mat={C('#efe6cc')} p={[-3.4, 5.3, 0]} />
    <Cyl rt={0.7} rb={0.8} h={2.6} mat={C('#2b2f36')} p={[-3.4, 7.2, 0]} />
    <Cyl rt={0.72} rb={0.72} h={0.5} mat={C('#a8352c')} p={[-3.4, 7.6, 0]} />
    <Cyl rt={0.07} h={5} mat={C('#5a4a3a')} p={[4.5, 5.2, 0]} seg={6} />
    <Box w={0.12} h={0.12} d={2.2} mat={C('#5a4a3a')} p={[4.5, 6.8, 0]} />
  </group>);
}
export function Crane({ p, hookY = 3, load = false, loadSpin = 0 }) {
  const steel = C('#c7822b');
  return (<group position={p}>
    {[[-1.6, -1], [1.6, -1], [-1.6, 1], [1.6, 1]].map(([x, z], i) => <Box key={i} w={0.2} h={7} d={0.2} mat={steel} p={[x, 3.5, z * 1.2]} />)}
    <Box w={3.8} h={0.3} d={3} mat={steel} p={[0, 7, 0]} />
    <Box w={9} h={0.35} d={0.5} mat={steel} p={[3.5, 7.4, 0]} />
    <Box w={0.04} h={7.4 - hookY} d={0.04} mat={C(INK)} p={[6.2, hookY + (7.4 - hookY) / 2, 0]} ink={false} />
    <Box w={0.3} h={0.3} d={0.3} mat={C('#2b2628')} p={[6.2, hookY, 0]} />
    {load && <group position={[6.2, hookY - 0.55, 0]} rotation={[0, loadSpin, 0]}><Box w={1} h={0.55} d={0.7} mat={M('stone', 0.5, 0.3)} /></group>}
  </group>);
}
