import React, { createContext, useContext } from 'react';
import * as THREE from 'three';
import { INK, memo, rngFrom, clamp, G } from './kit.jsx';

export const CamCtx = createContext({ x: 0, z: 10 });
const PPM = 300; // pixels per metre in character canvases

// ---------- hand-drawn ink helpers ----------
const circ = (cx, cy, rx, ry, n = 44) => Array.from({ length: n }, (_, i) => [cx + Math.cos((i / n) * 6.2832) * rx, cy + Math.sin((i / n) * 6.2832) * ry]);
function spline(c, closed = true, per = 7) {
  const out = [], n = c.length;
  const P = (i) => c[closed ? (i + n) % n : clamp(i, 0, n - 1)];
  const last = closed ? n : n - 1;
  for (let i = 0; i < last; i++) {
    const p0 = P(i - 1), p1 = P(i), p2 = P(i + 1), p3 = P(i + 2);
    for (let k = 0; k < per; k++) {
      const t = k / per, t2 = t * t, t3 = t2 * t;
      out.push([0, 1].map((a) => 0.5 * (2 * p1[a] + (-p0[a] + p2[a]) * t + (2 * p0[a] - 5 * p1[a] + 4 * p2[a] - p3[a]) * t2 + (-p0[a] + 3 * p1[a] - 3 * p2[a] + p3[a]) * t3)));
    }
  }
  if (!closed) out.push(c[n - 1]);
  return out;
}
function pathOf(ctx, pts, closed) { ctx.beginPath(); pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]))); if (closed) ctx.closePath(); }
// ink band: varying, slightly wobbly thickness
function ink(ctx, pts, r, { closed = true, w = 7 } = {}) {
  ctx.strokeStyle = INK; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  const n = pts.length, m = closed ? n : n - 1;
  for (let i = 0; i < m; i++) {
    const a = pts[i], b = pts[(i + 1) % n];
    ctx.lineWidth = w * (0.72 + 0.62 * r());
    ctx.beginPath(); ctx.moveTo(a[0] + (r() - 0.5) * 1.4, a[1] + (r() - 0.5) * 1.4); ctx.lineTo(b[0] + (r() - 0.5) * 1.4, b[1] + (r() - 0.5) * 1.4); ctx.stroke();
  }
}
function shape(ctx, pts, fill, r, o) { pathOf(ctx, pts, true); ctx.fillStyle = fill; ctx.fill(); ink(ctx, pts, r, o); }

// ---------- variants (palette, hat, glasses only) ----------
export const VARIANTS = {
  luckin:   { skin: '#f2dfc9', jacket: '#3f4b66', pants: '#2b2e3b', hat: 'bowler', glasses: true,  hair: '#2a1b18', tie: '#8a2b2b' },
  councilA: { skin: '#efd8c0', jacket: '#54413d', pants: '#2b2a2e', hat: 'top',    glasses: false, hair: '#3a2c26', tie: '#3b5a45' },
  councilB: { skin: '#f0dcc6', jacket: '#566b57', pants: '#2f3a33', hat: null,     glasses: false, hair: '#6b5a3a', tie: '#8a2b2b' },
  mcculloch:{ skin: '#f1d9c0', jacket: '#2f5d46', pants: '#3a3a42', hat: 'cap',    glasses: true,  hair: '#4a3a2c', tie: '#b6862d' },
  clerk:    { skin: '#efdcc8', jacket: '#6a5a7a', pants: '#34303c', hat: 'bowler', glasses: false, hair: '#2a1b18', tie: '#2b4a6a' },
  worker1:  { skin: '#e8cfb2', jacket: '#b8892f', pants: '#4b4b55', hat: 'cap',    glasses: false, hair: '#2a1b18', tie: null },
  worker2:  { skin: '#f0d8bf', jacket: '#4f7a8c', pants: '#43434d', hat: 'cap',    glasses: false, hair: '#5a4630', tie: null },
  engineer: { skin: '#f1dcc4', jacket: '#d8d4c8', pants: '#5a5a62', hat: 'cap',    glasses: true,  hair: '#2a1b18', tie: '#2b4a6a' },
  mayor:    { skin: '#f0d9c2', jacket: '#8a2c3a', pants: '#2a2a30', hat: 'top',    glasses: true,  hair: '#8a8a8a', tie: '#e6e0cc', chain: true },
  crowd1:   { skin: '#efd6bd', jacket: '#7a8f5a', pants: '#3a3d4a', hat: 'bowler', glasses: false, hair: '#3a2c26', tie: '#8a2b2b' },
  crowd2:   { skin: '#f2dfc9', jacket: '#a85f4a', pants: '#2e3440', hat: null,     glasses: true,  hair: '#8a5a2a', tie: '#2b4a6a' },
  crowd3:   { skin: '#ead2b8', jacket: '#4a5a7a', pants: '#3b3b44', hat: 'top',    glasses: false, hair: '#2a1b18', tie: '#b6862d' },
};
const shade = (hex, k) => { const c = new THREE.Color(hex); c.multiplyScalar(k); return '#' + c.getHexString(); };

function mkCanvasTex(w, h, draw) {
  const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t;
}
function headTex(v, key) {
  return memo('head:' + key, () => mkCanvasTex(320, 420, (ctx) => {
    const r = rngFrom('head' + key), cx = 160, cy = 290, R = 95;
    // ears
    shape(ctx, circ(cx - R + 4, cy + 12, 17, 22, 20), v.skin, r, { w: 6 });
    shape(ctx, circ(cx + R - 4, cy + 12, 17, 22, 20), v.skin, r, { w: 6 });
    // head
    shape(ctx, circ(cx, cy, R, R * 1.02, 56), v.skin, r, { w: 8 });
    // hair fringe
    const top = [], steps = 22;
    for (let i = 0; i <= steps; i++) { const a = (-170 + (160 * i) / steps) * Math.PI / 180; top.push([cx + Math.cos(a) * (R + 3), cy + Math.sin(a) * (R + 3)]); }
    const fr = [[cx + 84, cy - 28], [cx + 68, cy - 42], [cx + 52, cy - 24], [cx + 34, cy - 44], [cx + 14, cy - 22], [cx - 6, cy - 44], [cx - 26, cy - 24], [cx - 46, cy - 42], [cx - 62, cy - 26], [cx - 82, cy - 34]];
    shape(ctx, [...top, ...fr], v.hair, r, { w: 7 });
    // calm half-lidded eyes
    [-35, 35].forEach((dx) => {
      const ex = cx + dx, ey = cy + 8;
      shape(ctx, circ(ex, ey, 17, 15, 24), '#ffffff', r, { w: 5 });
      ctx.fillStyle = INK; ctx.beginPath(); ctx.arc(ex + 1, ey + 5, 7, 0, 7); ctx.fill();
      // lid covers the upper half
      ctx.save(); pathOf(ctx, circ(ex, ey, 16, 14, 24), true); ctx.clip(); ctx.fillStyle = v.skin; ctx.fillRect(ex - 20, ey - 20, 40, 21); ctx.restore();
      ink(ctx, [[ex - 19, ey - 1], [ex, ey - 3], [ex + 19, ey - 1]], r, { closed: false, w: 6 });
    });
    // tiny smile
    ink(ctx, spline([[cx - 20, cy + 52], [cx, cy + 60], [cx + 20, cy + 52]], false, 8), r, { closed: false, w: 5 });
    // glasses
    if (v.glasses) {
      [-35, 35].forEach((dx) => ink(ctx, circ(cx + dx, cy + 8, 27, 25, 28), r, { w: 5 }));
      ink(ctx, [[cx - 9, cy + 6], [cx + 9, cy + 6]], r, { closed: false, w: 5 });
    }
    // hats
    const hatC = '#2b2428';
    if (v.hat === 'top') {
      shape(ctx, circ(cx, cy - R + 8, 112, 15, 36), hatC, r, { w: 7 });
      shape(ctx, [[cx - 56, cy - R + 4], [cx - 52, cy - 232], [cx + 52, cy - 232], [cx + 56, cy - R + 4]].map((p) => [p[0], p[1] + 0]).concat([]), hatC, r, { w: 7 });
      shape(ctx, [[cx - 56, cy - R - 4], [cx - 55, cy - R - 28], [cx + 55, cy - R - 28], [cx + 56, cy - R - 4]], v.tie || '#8a2b2b', r, { w: 5 });
    } else if (v.hat === 'bowler') {
      const dome = []; for (let i = 0; i <= 24; i++) { const a = Math.PI + (Math.PI * i) / 24; dome.push([cx + Math.cos(a) * 82, cy - R + 14 + Math.sin(a) * 78]); }
      shape(ctx, circ(cx, cy - R + 14, 112, 15, 36), hatC, r, { w: 7 });
      shape(ctx, dome, hatC, r, { w: 7 });
      shape(ctx, [[cx - 82, cy - R + 8], [cx - 80, cy - R - 12], [cx + 80, cy - R - 12], [cx + 82, cy - R + 8]], '#5b4a4a', r, { w: 5 });
    } else if (v.hat === 'cap') {
      const dome = []; for (let i = 0; i <= 24; i++) { const a = Math.PI + (Math.PI * i) / 24; dome.push([cx + Math.cos(a) * 96, cy - R + 20 + Math.sin(a) * 58]); }
      shape(ctx, dome, v.jacket === '#2f5d46' ? '#3d4a58' : '#4c4c58', r, { w: 7 });
      shape(ctx, circ(cx + 18, cy - R + 24, 82, 12, 30), '#2b2428', r, { w: 6 });
    }
  }));
}
function bodyTex(v, key) {
  return memo('body:' + key, () => mkCanvasTex(300, 400, (ctx) => {
    const r = rngFrom('body' + key);
    // legs + shoes (thin tapered sticks)
    [1, -1].forEach((s) => {
      const X = (x) => 150 + s * (x - 150);
      shape(ctx, [[X(104), 225], [X(132), 225], [X(124), 372], [X(108), 372]].map((p) => p), v.pants, r, { w: 6 });
      shape(ctx, circ(X(113), 381, 27, 12, 24), '#2b2428', r, { w: 6 });
    });
    // pear shaped two-tone torso
    const torso = spline([[112, 52], [150, 42], [188, 52], [200, 92], [222, 150], [236, 202], [226, 234], [150, 248], [74, 234], [64, 202], [78, 150], [100, 92]], true, 8);
    pathOf(ctx, torso, true); ctx.fillStyle = v.jacket; ctx.fill();
    ctx.save(); pathOf(ctx, torso, true); ctx.clip(); ctx.fillStyle = v.pants; ctx.fillRect(0, 176, 300, 100); ctx.restore();
    ink(ctx, torso, r, { w: 8 });
    ink(ctx, [[72, 176], [150, 182], [228, 176]], r, { closed: false, w: 5 });
    // pocket patch with stitches
    shape(ctx, [[112, 108], [144, 108], [144, 134], [112, 134]], shade(v.jacket, 0.82), r, { w: 4 });
    ctx.strokeStyle = 'rgba(30,20,20,0.55)'; ctx.setLineDash([4, 4]); ctx.lineWidth = 2; ctx.strokeRect(116, 112, 24, 18); ctx.setLineDash([]);
    // white collar + tie
    shape(ctx, [[150, 44], [124, 54], [140, 86]], '#ffffff', r, { w: 5 });
    shape(ctx, [[150, 44], [176, 54], [160, 86]], '#ffffff', r, { w: 5 });
    if (v.tie) shape(ctx, [[150, 62], [141, 80], [150, 150], [159, 80]], v.tie, r, { w: 4 });
    if (v.chain) ink(ctx, spline([[118, 62], [150, 128], [182, 62]], false, 10), r, { closed: false, w: 7 });
    if (v.chain) { ctx.strokeStyle = '#e0b43a'; ctx.lineWidth = 3; pathOf(ctx, spline([[118, 62], [150, 128], [182, 62]], false, 10), false); ctx.stroke(); }
  }));
}
function armTex(v, key) {
  return memo('arm:' + key, () => mkCanvasTex(44, 232, (ctx) => {
    const r = rngFrom('arm' + key);
    shape(ctx, [[15, 8], [29, 8], [26, 188], [18, 188]], v.jacket, r, { w: 4 });
    shape(ctx, circ(22, 206, 14, 14, 18), '#2b2428', r, { w: 4 });
  }));
}
const shadowTex = memo('blob', () => mkCanvasTex(128, 128, (ctx) => {
  const g = ctx.createRadialGradient(64, 64, 4, 64, 64, 62); g.addColorStop(0, 'rgba(30,18,16,0.55)'); g.addColorStop(1, 'rgba(30,18,16,0)'); ctx.fillStyle = g; ctx.fillRect(0, 0, 128, 128);
}));
const spriteMat = (t, tint) => memo(`sm:${t.uuid}:${tint}`, () => new THREE.MeshBasicMaterial({ map: t, transparent: true, alphaTest: 0.35, color: tint, toneMapped: false }));
const blobMat = memo('blobmat', () => new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, depthWrite: false }));

// ---------- the person ----------
export function Person({ p = [0, 0, 0], v = 'luckin', yaw = 0, s = 1, armL = -0.14, armR = 0.14, phase = 0, t = 0, tint = '#ffffff', handL = null, handR = null, face = 1 }) {
  const cam = useContext(CamCtx);
  const def = VARIANTS[v];
  const turn = clamp(Math.atan2(cam.x - p[0], cam.z - p[2]), -0.7, 0.7) * face;
  const bobY = Math.sin(t * 2.1 + phase) * 0.012;
  const nod = Math.sin(t * 1.3 + phase) * 0.035;
  const sway = (k) => Math.sin(t * 1.7 + phase + k) * 0.07;
  const body = bodyTex(def, v), head = headTex(def, v), arm = armTex(def, v);
  const W = 300 / PPM, H = 400 / PPM;
  return (
    <group position={p} scale={s} rotation={[0, yaw + turn, 0]}>
      <mesh position={[0, 0.012, 0]} rotation={[-Math.PI / 2, 0, 0]} geometry={G.plane(0.95, 0.5)} material={blobMat} />
      <mesh position={[0, H / 2 + bobY * 0.3, 0]} geometry={G.plane(W, H)} material={spriteMat(body, tint)} />
      <group position={[-0.125, 1.12 + bobY * 0.3, 0.012]} rotation={[0, 0, armL + sway(0)]}>
        <mesh position={[0, -0.386, 0]} geometry={G.plane(44 / PPM, 232 / PPM)} material={spriteMat(arm, tint)} />
        <group position={[0, -0.69, 0.01]}>{handL}</group>
      </group>
      <group position={[0.125, 1.12 + bobY * 0.3, 0.012]} rotation={[0, 0, armR + sway(2)]}>
        <mesh position={[0, -0.386, 0]} geometry={G.plane(44 / PPM, 232 / PPM)} material={spriteMat(arm, tint)} />
        <group position={[0, -0.69, 0.01]}>{handR}</group>
      </group>
      <group position={[0, 1.617 + bobY, 0.025]} rotation={[0, 0, nod]}>
        <mesh geometry={G.plane(320 / PPM, 420 / PPM)} material={spriteMat(head, tint)} />
      </group>
    </group>
  );
}
