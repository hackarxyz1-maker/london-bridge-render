import { useEffect, useMemo } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { EffectComposer, RenderPass, EffectPass, DepthOfFieldEffect, VignetteEffect } from 'postprocessing';

// Depth of field + vignette, rendered manually at priority 1 so Remotion controls every frame.
export function Post({ focus = 8, range = 5, bokeh = 3.2 }) {
  const { gl, scene, camera, size } = useThree();
  const { composer, dof } = useMemo(() => {
    const composer = new EffectComposer(gl, { multisampling: 4 });
    composer.addPass(new RenderPass(scene, camera));
    const dof = new DepthOfFieldEffect(camera, { worldFocusDistance: focus, worldFocusRange: range, bokehScale: bokeh, resolutionScale: 0.5 });
    const vig = new VignetteEffect({ offset: 0.32, darkness: 0.55 });
    composer.addPass(new EffectPass(camera, dof, vig));
    return { composer, dof };
  }, [gl, scene, camera]);
  useEffect(() => { composer.setSize(size.width, size.height); }, [composer, size]);
  dof.circleOfConfusionMaterial.worldFocusDistance = focus;
  dof.circleOfConfusionMaterial.worldFocusRange = range;
  dof.bokehScale = bokeh;
  useFrame((_, dt) => { composer.render(dt); }, 1);
  return null;
}
