import React from 'react';
import { Composition } from 'remotion';
import { Video } from './Video.jsx';
import { DURATION, FPS } from './timing.js';
export const Root = () => (
  <Composition id="LondonBridge" component={Video} durationInFrames={DURATION} fps={FPS} width={720} height={1280} />
);
