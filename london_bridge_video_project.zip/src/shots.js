import * as THREE from 'three';
import { CUTS, W } from './timing.js';

// Per shot: location, mood, beat times (camera keys hit these moments) and local camera keys.
export const SHOTS = [
  { n: 1, loc: 'az', X: 0, mood: 'day', beats: [0, 3.2, 6.2],
    keys: [{ p: [0, 9.5, 38], l: [0, 3.4, -4] }, { p: [-1.5, 5.0, 24], l: [0.5, 4.2, 0] }, { p: [4, 5.2, 12], l: [6, 4.6, 0] }] },
  { n: 2, loc: 'thames', X: 60, mood: 'thames', beats: [6.2, 9.0, 11.85],
    keys: [{ p: [-9, 3.2, 28], l: [-1, 4.4, 0] }, { p: [-1, 4.6, 21], l: [0, 5.2, 0] }, { p: [5, 7.0, 13], l: [7, 6.4, 0] }] },
  { n: 3, loc: 'thames', X: 60, mood: 'thames', beats: [11.85, 14.3, 18.4],
    keys: [{ p: [-5.2, 1.3, 8.5], l: [-3.2, 1.2, 0] }, { p: [-0.5, 3.0, 13], l: [2, 4.5, 0] }, { p: [8, 3.8, 18], l: [10, 5.2, 0] }] },
  { n: 4, loc: 'chamber', X: 180, mood: 'room', beats: [18.4, 21.0, 23.7],
    keys: [{ p: [0, 1.5, 3.4], l: [0, 1.3, -0.9] }, { p: [0.2, 1.45, 2.5], l: [0.1, 1.3, -0.9] }, { p: [0.5, 1.5, 1.9], l: [0.3, 1.2, -0.2] }] },
  { n: 5, loc: 'office', X: 240, mood: 'room', beats: [23.7, 27.6, 32.45],
    keys: [{ p: [-3.2, 1.8, -0.2], l: [-3.2, 1.8, -2.4] }, { p: [0.1, 1.5, 1.4], l: [0.2, 1.3, -0.9] }, { p: [1.35, 1.4, 1.6], l: [1.35, 0.62, 0.4] }] },
  { n: 6, loc: 'quay', X: 300, mood: 'quay', beats: [32.45, 35.4, 40.7],
    keys: [{ p: [-2.2, 1.9, 6.0], l: [-0.6, 0.9, 0] }, { p: [-0.5, 1.5, 4.6], l: [-0.6, 1.0, 1.0] }, { p: [3.4, 1.9, 6.2], l: [4.6, 1.7, -0.4] }] },
  { n: 7, loc: 'cutaway', X: 360, mood: 'day', beats: [40.7, 42.4, 46.05],
    keys: [{ p: [0.5, 9, 13], l: [0, 2.0, 0] }, { p: [-1.0, 4.6, 9.5], l: [-0.6, 2.0, 0] }, { p: [2.6, 3.2, 8.4], l: [2.0, 1.8, 0] }] },
  { n: 8, loc: 'laying', X: 420, mood: 'day', beats: [46.05, 48.3, 53.25],
    keys: [{ p: [-4, 2.2, 9], l: [0, 1.4, 0] }, { p: [-0.6, 1.5, 5.2], l: [-0.2, 0.9, 0] }, { p: [3.2, 2.4, 8.5], l: [4.0, 3.0, 0] }] },
  { n: 9, loc: 'az', X: 0, mood: 'day', beats: [53.25, 56.4, 58.1],
    keys: [{ p: [-8, 11, 21], l: [-3, 5.0, 0] }, { p: [0, 10.5, 19], l: [2, 5.0, 0] }, { p: [5.5, 10, 17], l: [6.5, 5.0, 0] }] },
  { n: 10, loc: 'az', X: 0, mood: 'sunset', beats: [58.1, 62.4],
    keys: [{ p: [3.5, 3.2, 13], l: [1, 4.6, 0] }, { p: [-3, 6.2, 30], l: [0, 3.6, 0] }] },
];

export const MOODS = {
  day:    { fog: '#ecd9b0', near: 45, far: 190, key: '#fff0cf', ki: 2.7, hs: '#fff2d8', hg: '#d2ab78', hi: 1.15, lp: [-14, 22, 16], tint: '#ffffff', sky: ['#7fb7dc', '#cfe3e2', '#f1e2bd'] },
  thames: { fog: '#bfc1b6', near: 25, far: 120, key: '#f4ecd8', ki: 2.0, hs: '#e8ecee', hg: '#8f8c7e', hi: 1.45, lp: [-12, 20, 16], tint: '#f4f1ea', sky: ['#a9b4b8', '#cdd1cb', '#e5dfca'] },
  room:   { fog: '#6a5040', near: 60, far: 200, key: '#ffe3b4', ki: 2.1, hs: '#ffe9c8', hg: '#7a5640', hi: 1.3, lp: [-4, 9, 12], tint: '#ffffff', sky: ['#9cc4dc', '#d8e6e0', '#f1e6c6'] },
  quay:   { fog: '#cfd8d4', near: 40, far: 150, key: '#fff3dc', ki: 2.5, hs: '#eaf2f4', hg: '#9a9a8c', hi: 1.2, lp: [-12, 22, 14], tint: '#ffffff', sky: ['#86b4d2', '#c8dce0', '#ede2c6'] },
  sunset: { fog: '#e9a574', near: 40, far: 170, key: '#ffb070', ki: 3.1, hs: '#ffc9a0', hg: '#9a6a58', hi: 1.0, lp: [-42, 9, 14], tint: '#ffd9b8', sky: ['#6a6fa6', '#f0a070', '#ffd29a'] },
};

// ---- monotone-ish Hermite warp: camera arrives at each key on its beat, rests at both ends ----
function warpU(t, beats) {
  const n = beats.length, y = beats.map((_, i) => i / (n - 1));
  if (t <= beats[0]) return 0; if (t >= beats[n - 1]) return 1;
  const m = beats.map((b, i) => (i === 0 || i === n - 1) ? 0 : (y[i + 1] - y[i - 1]) / (beats[i + 1] - beats[i - 1]));
  let i = 0; while (i < n - 2 && t > beats[i + 1]) i++;
  const h = beats[i + 1] - beats[i], s = (t - beats[i]) / h, s2 = s * s, s3 = s2 * s;
  const u = (2 * s3 - 3 * s2 + 1) * y[i] + (s3 - 2 * s2 + s) * h * m[i] + (-2 * s3 + 3 * s2) * y[i + 1] + (s3 - s2) * h * m[i + 1];
  return Math.min(1, Math.max(0, u));
}
const curves = SHOTS.map((s) => ({
  p: new THREE.CatmullRomCurve3(s.keys.map((k) => new THREE.Vector3(k.p[0] + s.X, k.p[1], k.p[2])), false, 'centripetal'),
  l: new THREE.CatmullRomCurve3(s.keys.map((k) => new THREE.Vector3(k.l[0] + s.X, k.l[1], k.l[2])), false, 'centripetal'),
}));
export function shotIndex(t) { for (let i = 0; i < SHOTS.length; i++) if (t < CUTS[i + 1]) return i; return SHOTS.length - 1; }
export function cameraAt(t) {
  const i = shotIndex(t), s = SHOTS[i], u = warpU(t, s.beats);
  return { i, shot: s, pos: curves[i].p.getPoint(u), look: curves[i].l.getPoint(u) };
}
