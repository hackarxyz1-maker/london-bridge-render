import React from 'react';
import * as THREE from 'three';
import { AbsoluteFill, Audio, staticFile, useCurrentFrame, useVideoConfig } from 'remotion';
import { ThreeCanvas } from '@remotion/three';
import { Post } from './Post.jsx';
import { CamCtx } from './chars.jsx';
import { CREAM } from './kit.jsx';
import { cameraAt, MOODS, SHOTS } from './shots.js';
import { Arizona, BlvdSign, Thames, SinkingBits, Chamber, Office, Quay, Cutaway, Laying } from './worlds.jsx';
import { CUTS } from './timing.js';
import { useThree as useR3F } from '@react-three/fiber';

// Sets camera, fog, light each frame from the shot table
function Rig({ cam, mood }) {
  const { camera, scene } = useR3F();
  camera.position.copy(cam.pos); camera.lookAt(cam.look); camera.updateMatrixWorld();
  scene.fog = new THREE.Fog(mood.fog, mood.near, mood.far); scene.background = new THREE.Color(mood.fog);
  return null;
}
function Lights({ cam, mood }) {
  const X = cam.shot.X, ref = React.useRef();
  React.useLayoutEffect(() => { if (ref.current) { ref.current.target.position.set(X, 0, 0); ref.current.target.updateMatrixWorld(); } });
  return (<>
    <hemisphereLight args={[mood.hs, mood.hg, mood.hi]} />
    <directionalLight ref={ref} position={[X + mood.lp[0], mood.lp[1], mood.lp[2]]} intensity={mood.ki} color={mood.key} castShadow
      shadow-mapSize={[2048, 2048]} shadow-camera-left={-32} shadow-camera-right={32} shadow-camera-top={32} shadow-camera-bottom={-32} shadow-camera-near={1} shadow-camera-far={120} shadow-bias={-0.0006} />
    <primitive object={ref.current ? ref.current.target : new THREE.Object3D()} />
  </>);
}

export const Video = () => {
  const frame = useCurrentFrame(); const { fps } = useVideoConfig(); const t = frame / fps;
  const cam = cameraAt(t); const s = cam.shot; const mood = MOODS[s.mood]; const tint = mood.tint;
  const focus = cam.pos.distanceTo(cam.look);
  // cream dip on every location change
  let dip = 0;
  for (let i = 1; i < CUTS.length - 1; i++) {
    const a = SHOTS[i - 1], b = SHOTS[i]; if (a.loc === b.loc && a.mood === b.mood) continue;
    const d = Math.abs(t - CUTS[i]); if (d < 0.22) dip = Math.max(dip, 1 - d / 0.22);
  }
  const world = (() => {
    switch (s.loc) {
      case 'az': return <><Arizona t={t} X={0} moodSky={mood.sky} tint={tint} />{s.n >= 9 && <BlvdSign X={0} />}</>;
      case 'thames': return <><Thames t={t} X={60} moodSky={mood.sky} />{s.n === 3 && <SinkingBits X={60} t={t} />}</>;
      case 'chamber': return <Chamber t={t} X={180} />;
      case 'office': return <Office t={t} X={240} />;
      case 'quay': return <Quay t={t} X={300} />;
      case 'cutaway': return <Cutaway t={t} X={360} />;
      case 'laying': return <Laying t={t} X={420} />;
      default: return null;
    }
  })();
  return (
    <AbsoluteFill style={{ background: CREAM }}>
      <Audio src={staticFile('voiceover.wav')} />
      <ThreeCanvas width={720} height={1280} shadows camera={{ fov: 80, near: 0.1, far: 500, position: [0, 2, 10] }} gl={{ antialias: false }}>
        <CamCtx.Provider value={{ x: cam.pos.x - s.X, z: cam.pos.z }}>
          <Rig cam={cam} mood={mood} />
          <Lights cam={cam} mood={mood} />
          {world}
          <Post focus={focus} range={focus * 0.6} bokeh={3.4} />
        </CamCtx.Provider>
      </ThreeCanvas>
      <AbsoluteFill style={{ background: CREAM, opacity: dip, pointerEvents: 'none' }} />
    </AbsoluteFill>
  );
};
